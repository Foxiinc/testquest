#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import serial
import serial.tools.list_ports
import time
import threading
from PySide6.QtCore import QObject, Signal, QTimer

class ArduinoPulseReader(QObject):
    """Класс для чтения данных пульса с Arduino"""
    
    pulse_received = Signal(int)
    connection_status = Signal(bool)
    
    def __init__(self, port=None, baudrate=115200):
        super().__init__()
        self.port = port
        self.baudrate = baudrate
        self.serial_connection = None
        self.is_reading = False
        self.read_thread = None
        
    def find_arduino_port(self):
        """Поиск порта Arduino"""
        ports = serial.tools.list_ports.comports()
        for port in ports:
            # Ищем Arduino по описанию или VID/PID
            if any(keyword in port.description.lower() for keyword in ['arduino', 'ch340', 'cp210', 'ftdi']):
                return port.device
            # Проверяем стандартные VID для Arduino
            if port.vid in [0x2341, 0x1A86, 0x10C4]:  # Arduino, CH340, CP210x
                return port.device
        return None
        
    def connect(self):
        """Подключение к Arduino"""
        try:
            if not self.port:
                self.port = self.find_arduino_port()
                
            if not self.port:
                print("Arduino не найден")
                return False
                
            self.serial_connection = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=1,
                write_timeout=1
            )
            
            # Ждем инициализации Arduino
            time.sleep(2)
            
            # Очищаем буфер
            self.serial_connection.flushInput()
            self.serial_connection.flushOutput()
            
            print(f"Подключен к Arduino на порту {self.port}")
            self.connection_status.emit(True)
            return True
            
        except Exception as e:
            print(f"Ошибка подключения к Arduino: {e}")
            self.connection_status.emit(False)
            return False
            
    def disconnect(self):
        """Отключение от Arduino"""
        self.is_reading = False
        if self.read_thread and self.read_thread.is_alive():
            self.read_thread.join(timeout=2)
            
        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.close()
            print("Отключен от Arduino")
            
        self.connection_status.emit(False)
        
    def is_connected(self):
        """Проверка подключения"""
        return self.serial_connection and self.serial_connection.is_open
        
    def start_reading(self):
        """Запуск чтения данных"""
        if not self.is_connected():
            if not self.connect():
                return False
                
        self.is_reading = True
        self.read_thread = threading.Thread(target=self._read_data, daemon=True)
        self.read_thread.start()
        return True
        
    def stop_reading(self):
        """Остановка чтения данных"""
        self.is_reading = False
        if self.read_thread:
            self.read_thread.join(timeout=2)
            
    def _read_data(self):
        """Чтение данных в отдельном потоке"""
        buffer = ""
        
        while self.is_reading and self.is_connected():
            try:
                if self.serial_connection.in_waiting > 0:
                    # Читаем данные
                    data = self.serial_connection.read(self.serial_connection.in_waiting).decode('utf-8', errors='ignore')
                    buffer += data
                    
                    # Обрабатываем построчно
                    while '\n' in buffer:
                        line, buffer = buffer.split('\n', 1)
                        line = line.strip()
                        
                        if line:
                            self._parse_data(line)
                            
                else:
                    time.sleep(0.01)  # Небольшая задержка если нет данных
                    
            except Exception as e:
                print(f"Ошибка чтения данных: {e}")
                time.sleep(0.1)
                
    def _parse_data(self, line):
        """Парсинг строки данных"""
        try:
            # Ожидаем формат: "timestamp,pulse_value" или просто "pulse_value"
            if ',' in line:
                parts = line.split(',')
                if len(parts) >= 2:
                    pulse_value = int(float(parts[1]))
                else:
                    pulse_value = int(float(parts[0]))
            else:
                pulse_value = int(float(line))
                
            # Фильтруем разумные значения пульса
            if 30 <= pulse_value <= 200:
                self.pulse_received.emit(pulse_value)
                
        except (ValueError, IndexError) as e:
            # Игнорируем некорректные данные
            pass


def find_arduino_port():
    """Функция для поиска порта Arduino"""
    reader = ArduinoPulseReader()
    return reader.find_arduino_port()


# Тестирование
if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QTimer
    
    app = QApplication(sys.argv)
    
    def on_pulse_received(pulse):
        print(f"Получен пульс: {pulse} уд/мин")
        
    def on_connection_status(connected):
        print(f"Статус подключения: {'Подключен' if connected else 'Отключен'}")
    
    # Создаем читатель
    arduino = ArduinoPulseReader()
    arduino.pulse_received.connect(on_pulse_received)
    arduino.connection_status.connect(on_connection_status)
    
    # Запускаем чтение
    if arduino.start_reading():
        print("Чтение данных запущено...")
        
        # Таймер для остановки через 30 секунд
        def stop_test():
            arduino.stop_reading()
            arduino.disconnect()
            app.quit()
            
        QTimer.singleShot(30000, stop_test)
        
        sys.exit(app.exec())
    else:
        print("Не удалось запустить чтение данных")