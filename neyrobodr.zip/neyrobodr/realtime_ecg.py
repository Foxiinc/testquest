import serial
import numpy as np
from collections import deque
import time

class RealTimeECG:
    def __init__(self, port='COM4', baudrate=115200):
        self.ser = serial.Serial(port, baudrate)
        self.signal_buffer = deque(maxlen=100)  # Меньший буфер
        self.time_buffer = deque(maxlen=100)
        self.last_peak_time = 0
        self.bpm_history = deque(maxlen=3)  # История последних 3 измерений
        self.current_bpm = 75
        
    def read_data(self):
        if self.ser.in_waiting:
            line = self.ser.readline().decode().strip()
            try:
                timestamp, raw_value = map(int, line.split(','))
                self.signal_buffer.append(raw_value)
                self.time_buffer.append(timestamp)
                return timestamp, raw_value
            except:
                return None, None
        return None, None
    
    def detect_peak(self, current_signal, current_time):
        if len(self.signal_buffer) < 20:
            return False
            
        # Адаптивный порог на основе последних 20 значений
        recent_signals = list(self.signal_buffer)[-20:]
        baseline = np.mean(recent_signals)
        std_dev = np.std(recent_signals)
        threshold = baseline + 2 * std_dev  # Порог = среднее + 2 стандартных отклонения
        
        # Детекция пика
        if (current_signal > threshold and 
            current_time - self.last_peak_time > 400):  # Минимум 400мс между пиками
            
            if self.last_peak_time != 0:
                # Считаем BPM по интервалу
                interval = current_time - self.last_peak_time
                new_bpm = 60000 / interval
                
                if 50 <= new_bpm <= 150:  # Расширенный диапазон
                    self.bpm_history.append(new_bpm)
                    # Обновляем текущий BPM как среднее последних измерений
                    self.current_bpm = int(np.mean(list(self.bpm_history)))
            
            self.last_peak_time = current_time
            return True
        
        return False
    
    def run(self):
        print("Запуск реального времени ECG мониторинга...")
        last_display = 0
        
        while True:
            timestamp, raw_value = self.read_data()
            
            if raw_value is not None:
                # Проверяем на пик
                is_peak = self.detect_peak(raw_value, timestamp)
                
                # Показываем данные каждые 200мс или при обнаружении пика
                if timestamp - last_display > 200 or is_peak:
                    status = "💓 ПИК!" if is_peak else ""
                    print(f"⏰ {timestamp}мс | 📊 {raw_value} | ❤️ {self.current_bpm} BPM {status}")
                    last_display = timestamp
            
            time.sleep(0.001)

if __name__ == "__main__":
    monitor = RealTimeECG(port='COM4')
    monitor.run()