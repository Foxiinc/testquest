from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import requests


API_URL = "http://127.0.0.1:8000"


@dataclass(frozen=True)
class RemoteState:
    id: str
    last_name: str
    first_name: str
    middle_name: str
    age: str
    date: str
    time: str
    software_start_time: str
    drive_duration: str
    current_pulse: int
    operator_status: str


def push_state(state: RemoteState) -> None:
    """Отправка состояния оператора на FastAPI‑сервер. Ошибки молча игнорируются."""
    try:
        payload = state.__dict__
        requests.post(f"{API_URL}/state", json=payload, timeout=0.3)
    except Exception:
        # Сервер может быть не запущен — в этом случае просто молча пропускаем
        pass


def fetch_state(operator_id: str) -> Optional[RemoteState]:
    """Загрузка состояния с FastAPI‑сервера. Возвращает None, если сервер недоступен."""
    try:
        resp = requests.get(f"{API_URL}/state/{operator_id}", timeout=0.3)
        if resp.status_code != 200:
            return None
        data = resp.json()
        return RemoteState(
            id=str(data.get("id", "")),
            last_name=str(data.get("last_name", "")),
            first_name=str(data.get("first_name", "")),
            middle_name=str(data.get("middle_name", "")),
            age=str(data.get("age", "")),
            date=str(data.get("date", "")),
            time=str(data.get("time", "")),
            software_start_time=str(data.get("software_start_time", "")),
            drive_duration=str(data.get("drive_duration", "")),
            current_pulse=int(data.get("current_pulse", 0) or 0),
            operator_status=str(data.get("operator_status", "NORMAL")).upper() or "NORMAL",
        )
    except Exception:
        return None

