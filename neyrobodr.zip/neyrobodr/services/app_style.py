from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import QApplication


def load_qss(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return ""


def apply_app_style(app: QApplication, qss_path: Optional[Path] = None) -> None:
    """
    Единая точка применения стиля для всего приложения.
    Предпочитает style.qss в корне проекта.
    """
    if qss_path is None:
        qss_path = Path("style.qss")

    qss = load_qss(qss_path)
    if qss.strip():
        app.setStyleSheet(qss)
