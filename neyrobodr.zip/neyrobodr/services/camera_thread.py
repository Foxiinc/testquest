import cv2
from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QPixmap, QImage
from services.face_service import encode_face, compare_faces

class FaceAuthThread(QThread):
    success = Signal()  # Сигнал при успешной аутентификации
    frame_updated = Signal(QPixmap)  # Новый сигнал для обновления кадра в UI

    def __init__(self, known_encoding):
        super().__init__()
        self.known_encoding = known_encoding
        self.running = True
        self.frame_count = 0  # Счётчик для оптимизации обновлений

    def run(self):
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Ошибка: Камера не доступна!")
            return

        while self.running:
            ret, frame = cap.read()
            if not ret:
                continue

            # Конвертируем кадр в QPixmap для QLabel
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # OpenCV -> RGB
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w
            q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(q_img)

            # Эмитируем кадр для обновления UI (каждые 5 кадров для плавности)
            self.frame_count += 1
            if self.frame_count % 5 == 0:
                self.frame_updated.emit(pixmap)

            # Сравниваем лица
            if compare_faces(self.known_encoding, frame):
                self.success.emit()
                break

        cap.release()

    def stop(self):
        self.running = False
        self.wait()  # Ждём завершения потока