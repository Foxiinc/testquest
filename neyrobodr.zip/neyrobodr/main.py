
import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication

# Единый стиль приложения
from services.app_style import apply_app_style

# Импорт форм
from forms.start_form import StartWindow
from forms.registration_form import RegistrationWindow
from forms.authorization_form import AuthorizationWindow
from forms.monitoring_form import MonitoringWindow
from forms.instruction_form import InstructionWindow
from forms.analysis_form import AnalysisWindow
from forms.control_form import ControlForm


class NeurobodrApp(QApplication):
    """Главное приложение"""
    
    def __init__(self, argv):
        super().__init__(argv)
        self.setApplicationName("Нейрободр ")
        self.setApplicationVersion("1.0")
        
        # Создание папок
        Path("database").mkdir(exist_ok=True)
        Path("photos").mkdir(exist_ok=True)
        
        # Стартовое окно
        self.start_window = StartWindow(self)
        self.start_window.show()
        
        # Другие окна
        self.registration_window = None
        self.authorization_window = None
        self.monitoring_window = None
        self.instruction_window = None
        self.analysis_window = None
        self.control_window = None
        
    def show_registration(self):
        """Показать окно регистрации"""
        try:
            self.start_window.hide()
            
            # Закрываем предыдущее окно регистрации если есть
            if self.registration_window:
                self.registration_window.close()
                
            self.registration_window = RegistrationWindow(self)
            self.registration_window.show()
            
        except Exception as e:
            print(f"ОШИБКА открытия регистрации: {e}")
    
    def show_registration_instruction(self, operator_data):
        """Показать инструкцию после регистрации"""
        try:
            if self.registration_window:
                self.registration_window.close()
                
            self.show_instruction(operator_data)
            
        except Exception as e:
            print(f"Ошибка открытия инструкции регистрации: {e}")
        
    def show_authorization(self):
        """Показать окно авторизации"""
        try:
            self.start_window.hide()
            
            # Закрываем предыдущее окно авторизации если есть
            if self.authorization_window:
                self.authorization_window.close()
                
            self.authorization_window = AuthorizationWindow(self)
            self.authorization_window.show()
            
        except Exception as e:
            print(f"ОШИБКА открытия авторизации: {e}")
    
    def show_authorization_analysis(self, operator_data):
        """Показать анализ в режиме авторизации"""
        try:
            if self.authorization_window:
                self.authorization_window.close()
                
            self.show_analysis(operator_data, "authorization")
            
        except Exception as e:
            print(f"Ошибка открытия анализа авторизации: {e}")
        
    def show_monitoring(self, operator_id):
        """Показать окно мониторинга"""
        try:
            print(f"Переход к мониторингу для оператора {operator_id}")
            
            # Закрываем предыдущие окна
            if self.registration_window:
                self.registration_window.close()
            if self.authorization_window:
                self.authorization_window.close()
            if self.instruction_window:
                self.instruction_window.close()
            if self.analysis_window:
                self.analysis_window.close()
            if self.monitoring_window:
                self.monitoring_window.close()
                
            # ОСТОРОЖНО! Тут может быть краш
            self.monitoring_window = MonitoringWindow(self, operator_id)
            self.monitoring_window.show()
            
            print("Окно мониторинга открыто")
            
        except Exception as e:
            print(f"КРИТИЧЕСКАЯ ОШИБКА открытия мониторинга: {e}")
            # Возвращаемся к стартовому окну
            self.start_window.show()
    
    def show_instruction(self, operator_data):
        """Показать форму инструкции"""
        try:
            if self.instruction_window:
                self.instruction_window.close()
                
            self.instruction_window = InstructionWindow(self, operator_data)
            self.instruction_window.show()
            
        except Exception as e:
            print(f"Ошибка открытия инструкции: {e}")
    
    def show_analysis(self, operator_data, mode="registration"):
        """Показать форму анализа"""
        try:
            if self.analysis_window:
                self.analysis_window.close()
                
            self.analysis_window = AnalysisWindow(self, operator_data, mode)
            self.analysis_window.show()
            
        except Exception as e:
            print(f"Ошибка открытия анализа: {e}")
    
    def show_control(self, operator_data):
        """Показать форму управления"""
        try:
            if self.control_window:
                self.control_window.close()
                
            self.control_window = ControlForm(self, operator_data)
            self.control_window.show()
            
        except Exception as e:
            print(f"Ошибка открытия управления: {e}")


def main():
    """Главная функция"""
    try:
        app = NeurobodrApp(sys.argv)

        # Установка единого стиля из style.qss
        apply_app_style(app)
        
        print("Приложение запущено")
        sys.exit(app.exec())
        
    except Exception as e:
        print(f"КРИТИЧЕСКАЯ ОШИБКА запуска приложения: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
    