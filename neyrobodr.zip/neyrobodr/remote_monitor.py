#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Модуль Г: Программа удалённого мониторинга (Форма №6).

Источник данных: database/operators_db.csv
Запись туда уже выполняется в Form №5 (control_form.py) методом save_operator_data().

Запуск:
  python remote_monitor.py
"""

from __future__ import annotations

import csv
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QTimer, QPoint
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QBrush, QPolygon, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from services.app_style import apply_app_style
from services.state_client import fetch_state

DB_CSV_PATH = Path("database") / "operators_db.csv"
PHOTOS_DIR = Path("photos")


@dataclass(frozen=True)
class OperatorSnapshot:
    operator_id: str
    last_name: str
    first_name: str
    middle_name: str
    age: str
    date: str
    time: str
    software_start_time: str
    drive_duration: str
    current_pulse: int
    operator_status: str  # NORMAL / WARNING / CRITICAL


def _safe_int(value: str, default: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return default


def read_operator_snapshot(operator_id: str) -> Optional[OperatorSnapshot]:
    """Чтение состояния: сначала пробуем FastAPI, потом CSV."""
    # 1) Пытаемся взять актуальное состояние с веб‑сервера
    remote = fetch_state(operator_id)
    if remote:
        return OperatorSnapshot(
            operator_id=remote.id,
            last_name=remote.last_name,
            first_name=remote.first_name,
            middle_name=remote.middle_name,
            age=remote.age,
            date=remote.date,
            time=remote.time,
            software_start_time=remote.software_start_time,
            drive_duration=remote.drive_duration,
            current_pulse=remote.current_pulse,
            operator_status=remote.operator_status,
        )

    # 2) Фолбэк — читаем CSV, если сервер не запущен
    if not DB_CSV_PATH.exists():
        return None

    try:
        with DB_CSV_PATH.open("r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if not row:
                    continue
                if str(row.get("id", "")).strip() == str(operator_id).strip():
                    return OperatorSnapshot(
                        operator_id=str(row.get("id", "")).strip(),
                        last_name=str(row.get("last_name", "")).strip(),
                        first_name=str(row.get("first_name", "")).strip(),
                        middle_name=str(row.get("middle_name", "")).strip(),
                        age=str(row.get("age", "")).strip(),
                        date=str(row.get("date", "")).strip(),
                        time=str(row.get("time", "")).strip(),
                        software_start_time=str(row.get("software_start_time", "")).strip(),
                        drive_duration=str(row.get("drive_duration", "")).strip(),
                        current_pulse=_safe_int(str(row.get("current_pulse", "0")).strip(), 0),
                        operator_status=str(row.get("operator_status", "NORMAL")).strip().upper() or "NORMAL",
                    )
    except Exception:
        return None

    return None


class GeometricIndicator(QLabel):
    def __init__(self, shape: str, size: int = 54):
        super().__init__()
        self.shape = shape  # circle / triangle / square
        self.size = size
        self._color = QColor(150, 150, 150)
        self.setFixedSize(size, size)

    def set_color(self, color: QColor):
        self._color = color
        self.update()

    def paintEvent(self, event):  # noqa: N802 (Qt naming)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        pen = QPen(self._color, 2)
        brush = QBrush(self._color)
        painter.setPen(pen)
        painter.setBrush(brush)

        if self.shape == "circle":
            painter.drawEllipse(2, 2, self.size - 4, self.size - 4)
        elif self.shape == "triangle":
            points = [
                QPoint(self.size // 2, 2),
                QPoint(2, self.size - 2),
                QPoint(self.size - 2, self.size - 2),
            ]
            painter.drawPolygon(QPolygon(points))
        elif self.shape == "square":
            painter.drawRect(2, 2, self.size - 4, self.size - 4)


class DriverIdDialog(QDialog):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("Введите ID")
        self.setModal(False)  # по ТЗ окно отдельное
        self.setFixedSize(300, 140)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)

        title = QLabel("Введите ID_оператора")
        title.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        layout.addWidget(title)

        self.input = QLineEdit()
        self.input.setPlaceholderText("например: 123456")
        layout.addWidget(self.input)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.btn_next = QPushButton("Далее")
        self.btn_next.setFixedWidth(100)
        btn_row.addWidget(self.btn_next)
        layout.addLayout(btn_row)

        self.btn_next.clicked.connect(self.accept)
        self.input.returnPressed.connect(self.accept)

    def get_id(self) -> str:
        return self.input.text().strip()


class RemoteMonitorWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("НейроБодр — Удалённый мониторинг (Форма №6)")
        self.setMinimumSize(1200, 520)

        self.current_operator_id: Optional[str] = None
        self.last_status: Optional[str] = None

        self._build_ui()
        self._apply_styles()

        self.poll_timer = QTimer(self)
        self.poll_timer.timeout.connect(self._poll_data)
        self.poll_timer.start(1000)

        # стартовый экран + окно ввода ID
        QTimer.singleShot(0, self.reset_to_initial_state)

    def _apply_styles(self):
        self.setStyleSheet(
            """
            QMainWindow, QWidget { background-color: #F2F2F2; font-family: Arial; }
            QLabel { border: none; color: #111; }
            QPushButton {
                background-color: #333333; color: white; border: none;
                padding: 8px 14px; border-radius: 4px; font-weight: bold;
            }
            QPushButton:hover { background-color: #555555; }
            QLineEdit { border: none; padding: 8px; background: white; border-radius: 3px; }
            """
        )

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(8)

        # header
        header = QFrame()
        header.setFixedHeight(86)
        header.setStyleSheet("background-color: #43B02A; color: white;")
        h_layout = QVBoxLayout(header)
        h_layout.setContentsMargins(10, 10, 10, 10)
        h_layout.setSpacing(3)
        title = QLabel("НейроБодр")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("Arial", 28, QFont.Weight.Bold))
        title.setStyleSheet("text-decoration: underline;")
        subtitle = QLabel("Программа для мониторинга состояния водителей")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setFont(QFont("Arial", 12))
        h_layout.addWidget(title)
        h_layout.addWidget(subtitle)
        outer.addWidget(header)

        # content grid
        content = QWidget()
        grid = QGridLayout(content)
        grid.setContentsMargins(12, 10, 12, 12)
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(10)

        grid.addWidget(self._build_left_info(), 0, 0)
        grid.addWidget(self._build_center_terminal(), 0, 1)
        grid.addWidget(self._build_right_indicator(), 0, 2)
        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 4)
        grid.setColumnStretch(2, 3)
        outer.addWidget(content)

    def _build_left_info(self) -> QWidget:
        w = QFrame()
        w.setStyleSheet("background: #EAEAEA;")
        layout = QVBoxLayout(w)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        title = QLabel("Информация оператора")
        title.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        layout.addWidget(title)

        self.photo = QLabel()
        self.photo.setFixedSize(150, 150)
        self.photo.setStyleSheet("background: #D9D9D9;")
        self.photo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.photo)

        self.lbl_fio = QLabel("Фамилия Имя\nОтчество\nВозраст")
        self.lbl_fio.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        self.lbl_fio.setWordWrap(True)
        layout.addWidget(self.lbl_fio)

        self.lbl_datetime = QLabel("Дата/время: 00.00.0000 / 00:00:00")
        self.lbl_sw_start = QLabel("Время запуска ПО: 00:00:00")
        self.lbl_drive = QLabel("Время в дороге: 00:00:00")
        self.lbl_remaining = QLabel("Оставшееся время: 00:00:00")
        self.lbl_status = QLabel("Состояние: ")
        self.lbl_status_value = QLabel("НОРМА")
        self.lbl_status_value.setFont(QFont("Arial", 12, QFont.Weight.Bold))

        layout.addWidget(self.lbl_datetime)
        layout.addWidget(self.lbl_sw_start)
        layout.addWidget(self.lbl_drive)
        layout.addWidget(self.lbl_remaining)

        status_row = QHBoxLayout()
        status_row.addWidget(self.lbl_status)
        status_row.addWidget(self.lbl_status_value)
        status_row.addStretch()
        layout.addLayout(status_row)

        layout.addStretch()
        return w

    def _build_center_terminal(self) -> QWidget:
        w = QFrame()
        w.setStyleSheet("background: #0D0D0D;")
        layout = QVBoxLayout(w)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        title = QLabel("Терминальный блок")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("color: #E5E5E5; font-weight: bold; font-size: 14px;")
        layout.addWidget(title)

        self.terminal = QLabel("")
        self.terminal.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.terminal.setWordWrap(True)
        self.terminal.setStyleSheet(
            "background: transparent; color: #E5E5E5; font-size: 14px; font-weight: bold;"
        )
        layout.addWidget(self.terminal, 1)

        return w

    def _build_right_indicator(self) -> QWidget:
        w = QFrame()
        w.setStyleSheet("background: #EAEAEA;")
        layout = QVBoxLayout(w)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        title = QLabel("Блок индикации")
        title.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        layout.addWidget(title)

        self.lbl_pulse_title = QLabel("Пульс:")
        self.lbl_pulse_title.setFont(QFont("Arial", 20, QFont.Weight.Bold))
        layout.addWidget(self.lbl_pulse_title)

        self.lbl_pulse = QLabel("--")
        self.lbl_pulse.setFont(QFont("Arial", 30, QFont.Weight.Bold))
        self.lbl_pulse.setStyleSheet("color: #222;")
        layout.addWidget(self.lbl_pulse)

        ind_row = QHBoxLayout()
        ind_row.setSpacing(16)
        self.ind_circle = GeometricIndicator("circle")
        self.ind_triangle = GeometricIndicator("triangle")
        self.ind_square = GeometricIndicator("square")
        ind_row.addWidget(self.ind_circle)
        ind_row.addWidget(self.ind_triangle)
        ind_row.addWidget(self.ind_square)
        ind_row.addStretch()
        layout.addLayout(ind_row)

        layout.addStretch()

        self.btn_stop = QPushButton("Стоп программа")
        self.btn_stop.setFixedWidth(180)
        self.btn_stop.clicked.connect(self.reset_to_initial_state)
        layout.addWidget(self.btn_stop, 0, Qt.AlignmentFlag.AlignRight)

        return w

    def reset_to_initial_state(self):
        self.current_operator_id = None
        self.last_status = None
        self._set_placeholders()
        self._open_id_dialog()

    def _open_id_dialog(self):
        dlg = DriverIdDialog(self)
        dlg.input.setText("")
        dlg.show()

        def _on_accept():
            operator_id = dlg.get_id()
            if operator_id:
                self.current_operator_id = operator_id
                self._poll_data(force_terminal_intro=True)
            dlg.close()

        dlg.accepted.connect(_on_accept)

    def _set_placeholders(self):
        self.photo.setText("")
        self.photo.setPixmap(QPixmap())
        self.lbl_fio.setText("Фамилия Имя\nОтчество\nВозраст")
        self.lbl_datetime.setText("Дата/время: 00.00.0000 / 00:00:00")
        self.lbl_sw_start.setText("Время запуска ПО: 00:00:00")
        self.lbl_drive.setText("Время в дороге: 00:00:00")
        self.lbl_remaining.setText("Оставшееся время: 00:00:00")
        self.lbl_status_value.setText("НОРМА")
        self.lbl_status_value.setStyleSheet("color: #2E7D32; font-weight: bold;")
        self.lbl_pulse.setText("--")
        self.terminal.setText("")
        self._set_indicators("NORMAL")

    def _set_indicators(self, status: str):
        # погасить
        neutral = QColor(160, 160, 160)
        self.ind_circle.set_color(neutral)
        self.ind_triangle.set_color(neutral)
        self.ind_square.set_color(neutral)

        if status == "NORMAL":
            self.ind_circle.set_color(QColor(0, 200, 0))
        elif status == "WARNING":
            self.ind_triangle.set_color(QColor(240, 200, 0))
        elif status == "CRITICAL":
            self.ind_square.set_color(QColor(220, 0, 0))

    def _format_status_ru(self, status: str) -> str:
        if status == "WARNING":
            return "ВНИМАНИЕ"
        if status == "CRITICAL":
            return "КРИТИЧНО!"
        return "НОРМА"

    def _status_color(self, status: str) -> str:
        if status == "WARNING":
            return "#F4C542"
        if status == "CRITICAL":
            return "#E53935"
        return "#2E7D32"

    def _poll_data(self, force_terminal_intro: bool = False):
        # дата/время всегда текущее (как в макете)
        now = datetime.now()
        self.lbl_datetime.setText(f"Дата/время: {now.strftime('%d.%m.%Y')} / {now.strftime('%H:%M:%S')}")

        if not self.current_operator_id:
            return

        snap = read_operator_snapshot(self.current_operator_id)
        if not snap:
            self.terminal.setText("Оператор не найден. Проверьте ID и базу данных.")
            return

        full_name = f"{snap.last_name} {snap.first_name}\n{snap.middle_name}\n{snap.age} лет"
        self.lbl_fio.setText(full_name)

        # фото
        photo_path = PHOTOS_DIR / f"{snap.operator_id}.jpg"
        if photo_path.exists():
            pm = QPixmap(str(photo_path))
            self.photo.setPixmap(pm.scaled(self.photo.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else:
            self.photo.setPixmap(QPixmap())
            self.photo.setText("Фото\nне найдено")

        self.lbl_sw_start.setText(f"Время запуска ПО: {snap.software_start_time or '00:00:00'}")
        self.lbl_drive.setText(f"Время в дороге: {snap.drive_duration or '00:00:00'}")

        # оставшееся время — в проекте у вас 9 часов
        # считаем грубо по drive_duration HH:MM:SS (если не парсится — оставляем как есть)
        remaining_txt = "09:00:00"
        try:
            parts = (snap.drive_duration or "00:00:00").split(":")
            h, m, s = (int(parts[0]), int(parts[1]), int(parts[2]))
            elapsed = h * 3600 + m * 60 + s
            remaining = max(0, 9 * 3600 - elapsed)
            rh = remaining // 3600
            rm = (remaining % 3600) // 60
            rs = remaining % 60
            remaining_txt = f"{rh:02d}:{rm:02d}:{rs:02d}"
        except Exception:
            remaining_txt = "09:00:00"
        self.lbl_remaining.setText(f"Оставшееся время: {remaining_txt}")

        status = snap.operator_status or "NORMAL"
        self.lbl_status_value.setText(self._format_status_ru(status))
        self.lbl_status_value.setStyleSheet(f"color: {self._status_color(status)}; font-weight: bold;")

        self.lbl_pulse.setText(str(snap.current_pulse) if snap.current_pulse else "--")
        self.lbl_pulse.setStyleSheet(f"color: {self._status_color(status)};")
        self._set_indicators(status)

        # терминальные сообщения + "звуковое оповещение"
        lines = []
        if force_terminal_intro:
            lines.append(f"Подключение к оператору ID: {snap.operator_id}")
            lines.append("")

        if status == "NORMAL":
            lines.append("Состояние: НОРМА")
        elif status == "WARNING":
            lines.append("Состояние: ВНИМАНИЕ!")
            lines.append("Запуск звукового оповещения!")
            lines.append("Рекомендуется сделать остановку.")
        else:
            lines.append("Состояние критичное !")
            lines.append("Запуск звукового оповещения!")
            lines.append("Необходимо связаться с водителем!")

        self.terminal.setText("\n".join(lines))

        if self.last_status is None:
            self.last_status = status
        elif self.last_status != status:
            # Без внешних wav-файлов: делаем системный "beep" при смене статуса
            QApplication.beep()
            self.last_status = status


def main() -> int:
    app = QApplication(sys.argv)
    apply_app_style(app)
    w = RemoteMonitorWindow()
    w.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

