# ecg_processor.pyx
# cython: language_level=3
import numpy as np
cimport numpy as np
cimport cython

@cython.boundscheck(False)
@cython.wraparound(False)
def detect_peaks(np.ndarray[np.int32_t, ndim=1] signal, 
                 np.ndarray[np.int64_t, ndim=1] timestamps,
                 int threshold=100, 
                 int min_interval=500):
    """
    Быстрая детекция R-пиков в ECG сигнале
    """
    cdef int n = signal.shape[0]
    cdef int i
    cdef int baseline = np.mean(signal)
    cdef int filtered_val
    cdef list peaks = []
    cdef long last_peak_time = 0
    
    for i in range(1, n):
        # Простая фильтрация
        filtered_val = abs(signal[i] - baseline)
        
        # Детекция пика
        if (filtered_val > threshold and 
            timestamps[i] - last_peak_time > min_interval):
            peaks.append(i)
            last_peak_time = timestamps[i]
    
    return peaks

@cython.boundscheck(False)
def calculate_bpm(list peak_indices, 
                  np.ndarray[np.int64_t, ndim=1] timestamps):
    """
    Быстрый расчет BPM по пикам
    """
    if len(peak_indices) < 2:
        return 0
    
    cdef int last_idx = peak_indices[-1]
    cdef int prev_idx = peak_indices[-2]
    cdef long interval = timestamps[last_idx] - timestamps[prev_idx]
    
    if interval > 300:  # Минимум 300мс между ударами
        bpm = 60000 // interval
        if 50 <= bpm <= 120:
            return bpm
    
    return 0