#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import cv2
import numpy as np
import face_recognition
from PySide6.QtCore import QThread, Signal, QTimer
from PySide6.QtWidgets import QLabel
from PySide6.QtGui import QImage, QPixmap, QPainter, QColor, QFont
from PySide6.QtCore import Qt
import time

class EnhancedCameraThread(QThread):
    """Поток для работы с камерой с детекцией глаз и наклона головы"""
    frame_ready = Signal(np.ndarray)
    face_detected = Signal(bool, np.ndarray)
    eyes_status = Signal(bool)  # True - глаза открыты, False - закрыты
    head_tilt = Signal(float)   # Угол наклона головы в градусах
    microsleep_detected = Signal(bool)  # Микросон (глаза закрыты >3 сек)
    head_nod_detected = Signal(bool)    # Кивание головы (наклон >4 сек)
    
    def __init__(self):
        super().__init__()
        self.cap = None
        self.running = False
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
        
        # Счетчики для отслеживания времени
        self.eyes_closed_start = None
        self.head_tilted_start = None
        
    def start_camera(self):
        """Запуск камеры"""
        try:
            backends = [cv2.CAP_ANY, cv2.CAP_DSHOW, cv2.CAP_MSMF]
            
            for backend in backends:
                try:
                    self.cap = cv2.VideoCapture(0, backend)
                    if self.cap.isOpened():
                        ret, test_frame = self.cap.read()
                        if ret and test_frame is not None:
                            print(f"Камера запущена с backend: {backend}")
                            break
                        else:
                            self.cap.release()
                            self.cap = None
                    else:
                        self.cap = None
                except Exception as e:
                    print(f"Backend {backend} не работает: {e}")
                    continue
            
            if not self.cap or not self.cap.isOpened():
                return False
                
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
            
            self.running = True
            self.start()
            return True
        except Exception as e:
            print(f"Ошибка запуска камеры: {e}")
            return False
        
    def stop_camera(self):
        """Остановка камеры"""
        self.running = False
        if self.cap:
            self.cap.release()
        self.quit()
        self.wait()
        
    def detect_eyes_and_tilt(self, frame):
        """Детекция глаз и наклона головы с визуализацией"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
        
        eyes_open = False
        head_angle = 0.0
        current_time = time.time()
        
        # Рисуем рамки вокруг лиц
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, "FACE", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
            
            # Детекция глаз
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = frame[y:y+h, x:x+w]
            eyes = self.eye_cascade.detectMultiScale(roi_gray)
            
            # Рисуем рамки вокруг глаз
            for (ex, ey, ew, eh) in eyes:
                cv2.rectangle(roi_color, (ex, ey), (ex+ew, ey+eh), (255, 0, 0), 1)
                
            eyes_open = len(eyes) >= 2
            
            # Расчет наклона головы
            if len(eyes) >= 2:
                eye1 = (x + eyes[0][0] + eyes[0][2]//2, y + eyes[0][1] + eyes[0][3]//2)
                eye2 = (x + eyes[1][0] + eyes[1][2]//2, y + eyes[1][1] + eyes[1][3]//2)
                
                # Рисуем линию между глазами
                cv2.line(frame, eye1, eye2, (255, 255, 0), 2)
                
                dx = eye2[0] - eye1[0]
                dy = eye2[1] - eye1[1]
                head_angle = np.degrees(np.arctan2(dy, dx))
                
                # Показываем угол наклона
                cv2.putText(frame, f"Angle: {head_angle:.1f}", (x, y+h+20), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 1)
            
            break  # Берем только первое лицо
            
        # Отслеживание времени закрытых глаз
        if not eyes_open:
            if self.eyes_closed_start is None:
                self.eyes_closed_start = current_time
            elif current_time - self.eyes_closed_start > 3.0:  # 3 секунды
                self.microsleep_detected.emit(True)
                cv2.putText(frame, "MICROSLEEP!", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        else:
            self.eyes_closed_start = None
            self.microsleep_detected.emit(False)
            
        # Отслеживание времени наклона головы
        if abs(head_angle) > 15:  # Наклон больше 15 градусов
            if self.head_tilted_start is None:
                self.head_tilted_start = current_time
            elif current_time - self.head_tilted_start > 4.0:  # 4 секунды
                self.head_nod_detected.emit(True)
                cv2.putText(frame, "HEAD NOD!", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        else:
            self.head_tilted_start = None
            self.head_nod_detected.emit(False)
            
        # Статус глаз
        eye_status = "OPEN" if eyes_open else "CLOSED"
        eye_color = (0, 255, 0) if eyes_open else (0, 0, 255)
        cv2.putText(frame, f"Eyes: {eye_status}", (10, frame.shape[0]-40), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, eye_color, 1)
        
        # Количество обнаруженных лиц
        cv2.putText(frame, f"Faces: {len(faces)}", (10, frame.shape[0]-20), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        return eyes_open, head_angle
        
    def run(self):
        """Основной цикл"""
        consecutive_fails = 0
        while self.running and self.cap and self.cap.isOpened():
            try:
                ret, frame = self.cap.read()
                if ret and frame is not None:
                    consecutive_fails = 0
                    
                    if not hasattr(self, 'frame_count'):
                        self.frame_count = 0
                    self.frame_count += 1
                    
                    # Детекция глаз и наклона каждый кадр для точности
                    try:
                        eyes_open, head_angle = self.detect_eyes_and_tilt(frame)
                        self.eyes_status.emit(eyes_open)
                        self.head_tilt.emit(head_angle)
                    except:
                        self.eyes_status.emit(True)
                        self.head_tilt.emit(0.0)
                    
                    self.frame_ready.emit(frame)
                    
                    # Face recognition каждые 15 кадров
                    if self.frame_count % 15 == 0:
                        try:
                            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
                            rgb_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                            face_locations = face_recognition.face_locations(rgb_frame)
                            
                            if face_locations:
                                face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
                                if face_encodings:
                                    self.face_detected.emit(True, face_encodings[0])
                                else:
                                    self.face_detected.emit(False, np.array([]))
                            else:
                                self.face_detected.emit(False, np.array([]))
                        except:
                            self.face_detected.emit(False, np.array([]))
                else:
                    consecutive_fails += 1
                    if consecutive_fails > 20:
                        break
                        
            except Exception as e:
                consecutive_fails += 1
                if consecutive_fails > 20:
                    print(f"Критическая ошибка: {e}")
                    break
                
            self.msleep(66)


class CameraWidget(QLabel):
    """Виджет для отображения камеры"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(200, 150)
        self.setStyleSheet("border: 2px solid #4CAF50; border-radius: 10px; background-color: black;")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setText("КАМЕРА\nОЖИДАНИЕ...")
        self.setStyleSheet("color: white; font-weight: bold;")
        
        self.camera_thread = EnhancedCameraThread()
        self.camera_thread.frame_ready.connect(self.update_frame)
        
    def start_camera(self):
        """Запуск камеры"""
        return self.camera_thread.start_camera()
        
    def stop_camera(self):
        """Остановка камеры"""
        self.camera_thread.stop_camera()
        
    def update_frame(self, frame):
        """Обновление кадра"""
        try:
            # Конвертируем BGR в RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w
            
            # Создаем QImage
            qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
            
            # Масштабируем под размер виджета
            scaled_image = qt_image.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            
            # Устанавливаем как pixmap
            self.setPixmap(QPixmap.fromImage(scaled_image))
        except Exception as e:
            print(f"Ошибка обновления кадра: {e}")