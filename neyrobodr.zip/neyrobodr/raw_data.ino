#define SAMPLE_RATE 250

void setup() {
  Serial.begin(115200);
}

void loop() {
  int raw = analogRead(A0);
  unsigned long timestamp = millis();
  
  Serial.print(timestamp);
  Serial.print(",");
  Serial.println(raw);
  
  delay(1000 / SAMPLE_RATE);
}