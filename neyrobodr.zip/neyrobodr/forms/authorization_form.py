#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
import numpy as np
from pathlib import Path
import cv2
import face_recognition

from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, QMessageBox
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont

from .camera_base import CameraThread


class AuthorizationWindow(QWidget):
    """Окно авторизации"""
    
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.camera_thread = CameraThread()
        self.init_ui()
        
    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("Авторизация оператора")
        self.setMinimumSize(400, 300)
        
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(20)
        
        title = QLabel("Авторизация оператора")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        id_label = QLabel("Введите ID:")
        id_label.setFont(QFont("Arial", 12, QFont.Bold))
        layout.addWidget(id_label)
        
        self.id_edit = QLineEdit()
        self.id_edit.setPlaceholderText("Введите 6-значный ID")
        self.id_edit.setMaxLength(6)
        layout.addWidget(self.id_edit)
        
        auth_btn = QPushButton("Авторизоваться")
        auth_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                font-size: 14px;
                padding: 10px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #555555;
            }
        """)
        auth_btn.clicked.connect(self.authorize)
        layout.addWidget(auth_btn)
        
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        
    def authorize(self):
        """Авторизация оператора"""
        operator_id = self.id_edit.text().strip()
        
        if len(operator_id) != 6 or not operator_id.isdigit():
            self.show_error("ID должен содержать 6 цифр")
            return
            
        csv_file = Path("database") / "operators_db.csv"
        operator_found = False
        
        if csv_file.exists():
            try:
                with open(csv_file, "r", encoding="utf-8") as f:
                    reader = csv.reader(f)
                    next(reader, None)
                    for row in reader:
                        if row and str(row[0]) == operator_id:
                            operator_data = {
                                "id": row[0],
                                "surname": row[1],
                                "name": row[2],
                                "patronymic": row[3],
                                "age": row[4]
                            }
                            operator_found = True
                            break
            except:
                pass
        
        if not operator_found:
            self.show_error("Оператор с таким ID не найден")
            return
            
        try:
            npy_file = Path("database") / f"{operator_id}.npy"
            
            if npy_file.exists():
                stored_encoding = np.load(npy_file)
                self.verify_face(operator_id, stored_encoding, operator_data)
            else:
                self.authorization_success(operator_id, operator_data)
                
        except Exception as e:
            self.show_error(f"Ошибка загрузки данных: {e}")
            
    def verify_face(self, operator_id, stored_encoding, operator_data):
        """Проверка лица через камеру"""
        self.status_label.setText("Посмотрите в камеру для проверки...")
        self.status_label.setStyleSheet("color: blue;")
        
        try:
            if not self.camera_thread.start_camera():
                self.status_label.setText("Камера недоступна - авторизация по ID")
                self.status_label.setStyleSheet("color: orange;")
                QTimer.singleShot(1500, lambda: self.authorization_success(operator_id, operator_data))
                return
                
            self.verification_timer = QTimer()
            self.verification_timer.timeout.connect(lambda: self.check_face_match(operator_id, stored_encoding, operator_data))
            self.verification_timer.start(1000)
            
            self.timeout_timer = QTimer()
            self.timeout_timer.timeout.connect(self.verification_timeout)
            self.timeout_timer.setSingleShot(True)
            self.timeout_timer.start(10000)
            
        except Exception as e:
            self.status_label.setText(f"Ошибка камеры - авторизация по ID")
            self.status_label.setStyleSheet("color: orange;")
            QTimer.singleShot(1500, lambda: self.authorization_success(operator_id, operator_data))
        
    def check_face_match(self, operator_id, stored_encoding, operator_data):
        """Проверка совпадения лица"""
        try:
            if self.camera_thread.cap and self.camera_thread.cap.isOpened():
                ret, frame = self.camera_thread.cap.read()
                if ret:
                    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    face_locations = face_recognition.face_locations(rgb_frame)
                    
                    if face_locations:
                        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
                        if face_encodings:
                            current_encoding = face_encodings[0]
                            distance = face_recognition.face_distance([stored_encoding], current_encoding)[0]
                            
                            if distance < 0.45:
                                self.verification_timer.stop()
                                self.timeout_timer.stop()
                                self.camera_thread.stop_camera()
                                self.authorization_success(operator_id, operator_data)
                                return
                                
        except Exception as e:
            print(f"Ошибка проверки лица: {e}")
            
    def authorization_success(self, operator_id, operator_data):
        """Успешная авторизация"""
        if hasattr(self, 'verification_timer'):
            self.verification_timer.stop()
        if hasattr(self, 'timeout_timer'):
            self.timeout_timer.stop()
        self.camera_thread.stop_camera()
        
        self.status_label.setText("✅ Авторизация успешна!")
        self.status_label.setStyleSheet("color: green; font-weight: bold;")
        
        QMessageBox.information(self, "Успех", f"Добро пожаловать, {operator_data['name']}!")
        
        # Переходим к анализу в режиме авторизации
        self.main_app.show_authorization_analysis(operator_data)
        self.close()
        
    def verification_timeout(self):
        """Таймаут авторизации"""
        self.verification_timer.stop()
        self.camera_thread.stop_camera()
        self.show_error("Время авторизации истекло")
        
    def show_error(self, message):
        """Показ ошибки"""
        self.status_label.setText(f"❌ {message}")
        self.status_label.setStyleSheet("color: red; font-weight: bold;")
        
    def closeEvent(self, event):
        """Обработка закрытия окна"""
        if hasattr(self, 'verification_timer'):
            self.verification_timer.stop()
        if hasattr(self, 'timeout_timer'):
            self.timeout_timer.stop()
        self.camera_thread.stop_camera()
        event.accept()