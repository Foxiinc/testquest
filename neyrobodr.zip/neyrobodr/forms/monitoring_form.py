#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
from datetime import datetime, timedelta
from pathlib import Path
import cv2
import face_recognition

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, 
    QLabel, QFrame
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QPixmap, QImage

from .camera_base import CameraThread


class MonitoringWindow(QMainWindow):
    """Главное окно мониторинга - ЗДЕСЬ СКОРЕЕ ВСЕГО КРАШ"""
    
    def __init__(self, main_app, operator_id):
        super().__init__()
        self.main_app = main_app
        self.operator_id = operator_id
        self.operator_data = None
        self.camera_thread = None  # Инициализируем как None
        self.start_time = datetime.now()
        self.work_duration = timedelta(hours=9)
        
        # Сначала загружаем данные
        self.load_operator_data()
        
        # Потом UI
        self.init_ui()
        
        # И только потом камеру - ОСТОРОЖНО!
        self.setup_camera()
        self.setup_timers()
        
    def load_operator_data(self):
        """Загрузка данных оператора"""
        try:
            csv_file = Path("database") / "operators_db.csv"
            if csv_file.exists():
                with open(csv_file, "r", encoding="utf-8") as f:
                    reader = csv.reader(f)
                    next(reader, None)
                    for row in reader:
                        if row and str(row[0]) == str(self.operator_id):
                            self.operator_data = {
                                "id": row[0],
                                "surname": row[1],
                                "name": row[2],
                                "patronymic": row[3],
                                "age": row[4]
                            }
                            break
        except Exception as e:
            print(f"Ошибка загрузки данных оператора: {e}")
            
    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("НейроБодр - Мониторинг")
        self.setMinimumSize(1300, 550)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(10)
        
        # Зеленая полоса сверху
        header = QFrame()
        header.setStyleSheet("background-color: #4CAF50; color: white; padding: 8px;")
        header.setFixedHeight(80)
        
        header_layout = QVBoxLayout(header)
        header_layout.setSpacing(2)
        
        title = QLabel("НейроБодр")
        title.setFont(QFont("Arial", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("text-decoration: underline;")
        
        subtitle = QLabel("Программа для мониторинга состояния водителей")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setAlignment(Qt.AlignCenter)
        
        header_layout.addWidget(title)
        header_layout.addWidget(subtitle)
        
        # Основной контент
        content_widget = QWidget()
        content_layout = QGridLayout(content_widget)
        content_layout.setSpacing(15)
        
        left_widget = self.create_operator_info()
        content_layout.addWidget(left_widget, 0, 0)
        
        center_widget = self.create_monitoring_camera()
        content_layout.addWidget(center_widget, 0, 1)
        
        right_widget = self.create_monitoring_info()
        content_layout.addWidget(right_widget, 0, 2)
        
        content_layout.setColumnStretch(0, 1)
        content_layout.setColumnStretch(1, 2)
        content_layout.setColumnStretch(2, 1)
        
        main_layout.addWidget(header)
        main_layout.addWidget(content_widget)
        
        # ОТЛОЖЕННЫЙ запуск мониторинга - может тут проблема
        QTimer.singleShot(3000, self.start_monitoring)  # Увеличил до 3 сек
        
    def create_operator_info(self):
        """Создание блока информации об операторе"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        title = QLabel("Информация оператора")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        # Фото оператора
        self.photo_label = QLabel()
        self.photo_label.setFixedSize(150, 150)
        self.photo_label.setStyleSheet("border: 2px solid #cccccc; background-color: #f0f0f0;")
        self.photo_label.setAlignment(Qt.AlignCenter)
        self.load_operator_photo()
        layout.addWidget(self.photo_label)
        
        if self.operator_data:
            full_name = f"{self.operator_data['surname']} {self.operator_data['name']} {self.operator_data['patronymic']}"
            name_label = QLabel(full_name)
            name_label.setFont(QFont("Arial", 12, QFont.Bold))
            name_label.setWordWrap(True)
            layout.addWidget(name_label)
            
            age_label = QLabel(f"Возраст: {self.operator_data['age']}")
            layout.addWidget(age_label)
            
        # Временные метки
        self.datetime_label = QLabel()
        self.start_time_label = QLabel(f"Время запуска ПО: {self.start_time.strftime('%H:%M:%S')}")
        self.work_time_label = QLabel("Время в дороге: 00:00:00")
        self.remaining_time_label = QLabel("Оставшееся время: 09:00:00")
        
        layout.addWidget(self.datetime_label)
        layout.addWidget(self.start_time_label)
        layout.addWidget(self.work_time_label)
        layout.addWidget(self.remaining_time_label)
        
        layout.addStretch()
        return widget
        
    def create_monitoring_camera(self):
        """Создание виджета камеры для мониторинга"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignCenter)
        
        title = QLabel("Мониторинг состояния")
        title.setFont(QFont("Arial", 12, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # ОСТОРОЖНО! Тут может быть проблема с видео
        self.monitor_video_frame = QLabel()
        self.monitor_video_frame.setFixedSize(400, 280)
        self.monitor_video_frame.setStyleSheet("border: 2px solid #cccccc; background-color: #f0f0f0;")
        self.monitor_video_frame.setAlignment(Qt.AlignCenter)
        self.monitor_video_frame.setText("Ожидание камеры...")
        layout.addWidget(self.monitor_video_frame, 0, Qt.AlignCenter)
        
        self.monitor_status = QLabel("Ожидание запуска мониторинга")
        self.monitor_status.setAlignment(Qt.AlignCenter)
        self.monitor_status.setStyleSheet("color: blue; font-weight: bold; font-size: 12px;")
        layout.addWidget(self.monitor_status)
        
        return widget
        
    def create_monitoring_info(self):
        """Создание информационного блока мониторинга"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        title = QLabel("Информационный блок")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        self.monitor_operator_status = QLabel("✅ Оператор определён")
        self.monitor_operator_status.setStyleSheet("color: green; font-weight: bold;")
        layout.addWidget(self.monitor_operator_status)
        
        self.monitor_id_label = QLabel(f"ID {self.operator_id}")
        self.monitor_id_label.setStyleSheet("""
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
        """)
        layout.addWidget(self.monitor_id_label)
        
        layout.addStretch()
        return widget
        
    def load_operator_photo(self):
        """Загрузка фото оператора"""
        try:
            photo_path = Path("photos") / f"{self.operator_id}.jpg"
            if photo_path.exists():
                pixmap = QPixmap(str(photo_path))
                scaled_pixmap = pixmap.scaled(self.photo_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.photo_label.setPixmap(scaled_pixmap)
            else:
                self.photo_label.setText("Фото\\nне найдено")
        except Exception as e:
            print(f"Ошибка загрузки фото: {e}")
            self.photo_label.setText("Ошибка\\nзагрузки")
            
    def setup_camera(self):
        """ОСТОРОЖНАЯ настройка камеры для мониторинга"""
        try:
            # Создаем новый поток камеры
            self.camera_thread = CameraThread()
            
            # Подключение сигналов с защитой
            self.camera_thread.frame_ready.connect(self.update_monitor_frame, Qt.QueuedConnection)
            self.camera_thread.face_detected.connect(self.on_monitor_face_detected, Qt.QueuedConnection)
            
            print("Камера для мониторинга настроена")
            
        except Exception as e:
            print(f"ОШИБКА настройки камеры мониторинга: {e}")
            self.camera_thread = None
            self.monitor_status.setText("❌ Ошибка настройки камеры")
            self.monitor_status.setStyleSheet("color: red; font-weight: bold;")
        
    def setup_timers(self):
        """Настройка таймеров"""
        try:
            # Таймер обновления времени
            self.time_timer = QTimer()
            self.time_timer.timeout.connect(self.update_time_labels)
            self.time_timer.start(1000)
            
            # Таймер проверки лица
            self.face_check_timer = QTimer()
            self.face_check_timer.timeout.connect(self.periodic_face_check)
            
            print("Таймеры настроены")
            
        except Exception as e:
            print(f"ОШИБКА настройки таймеров: {e}")
        
    def update_time_labels(self):
        """Обновление временных меток"""
        try:
            now = datetime.now()
            
            self.datetime_label.setText(f"Дата/время: {now.strftime('%d.%m.%Y %H:%M:%S')}")
            
            work_elapsed = now - self.start_time
            hours, remainder = divmod(work_elapsed.total_seconds(), 3600)
            minutes, seconds = divmod(remainder, 60)
            self.work_time_label.setText(f"Время в дороге: {int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}")
            
            # Обновляем CSV каждую минуту
            if not hasattr(self, 'csv_update_counter'):
                self.csv_update_counter = 0
            self.csv_update_counter += 1
            if self.csv_update_counter >= 60:
                self.update_csv_with_drive_duration()
                self.csv_update_counter = 0
                
            remaining = self.work_duration - work_elapsed
            if remaining.total_seconds() > 0:
                hours, remainder = divmod(remaining.total_seconds(), 3600)
                minutes, seconds = divmod(remainder, 60)
                self.remaining_time_label.setText(f"Оставшееся время: {int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}")
            else:
                self.remaining_time_label.setText("Время работы истекло!")
                self.remaining_time_label.setStyleSheet("color: red; font-weight: bold;")
                
        except Exception as e:
            print(f"ОШИБКА обновления времени: {e}")
            
    def start_monitoring(self):
        """ОСТОРОЖНЫЙ запуск мониторинга"""
        try:
            print("Попытка запуска мониторинга...")
            
            if self.camera_thread is None:
                print("ОШИБКА: camera_thread не инициализирован!")
                self.monitor_status.setText("❌ Камера не инициализирована")
                self.monitor_status.setStyleSheet("color: red; font-weight: bold;")
                return
                
            if self.camera_thread.start_camera():
                print("Камера мониторинга запущена успешно")
                self.monitor_status.setText("🟢 Мониторинг активен")
                self.monitor_status.setStyleSheet("color: green; font-weight: bold; font-size: 14px;")
                
                # Запуск периодической проверки лица
                self.face_check_timer.start(5000)
            else:
                print("ОШИБКА: Не удалось запустить камеру мониторинга")
                self.monitor_status.setText("❌ Ошибка запуска камеры")
                self.monitor_status.setStyleSheet("color: red; font-weight: bold; font-size: 14px;")
                
        except Exception as e:
            print(f"КРИТИЧЕСКАЯ ОШИБКА запуска мониторинга: {e}")
            self.monitor_status.setText("❌ Критическая ошибка")
            self.monitor_status.setStyleSheet("color: red; font-weight: bold;")
            
    def update_monitor_frame(self, frame):
        """ОСТОРОЖНОЕ обновление кадра мониторинга"""
        try:
            if frame is None:
                print("ОШИБКА: Получен пустой кадр")
                return
                
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Рисование рамки если лицо найдено
            if hasattr(self, 'monitor_face_found') and self.monitor_face_found:
                try:
                    small_frame = cv2.resize(rgb_frame, (0, 0), fx=0.25, fy=0.25)
                    face_locations = face_recognition.face_locations(small_frame)
                    
                    if face_locations:
                        top, right, bottom, left = face_locations[0]
                        top *= 4
                        right *= 4
                        bottom *= 4
                        left *= 4
                        
                        cv2.rectangle(rgb_frame, (left, top), (right, bottom), (0, 255, 0), 3)
                except Exception as e:
                    print(f"Ошибка рисования рамки: {e}")
            
            # Конвертация в QImage
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w
            qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            
            # Масштабирование
            pixmap = QPixmap.fromImage(qt_image)
            scaled_pixmap = pixmap.scaled(self.monitor_video_frame.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            
            self.monitor_video_frame.setPixmap(scaled_pixmap)
            
        except Exception as e:
            print(f"ОШИБКА обновления видео мониторинга: {e}")
            
    def on_monitor_face_detected(self, found, encoding):
        """Обработка обнаружения лица в мониторинге"""
        try:
            self.monitor_face_found = found
            
            if found and len(encoding) > 0:
                self.monitor_operator_status.setText("✅ Оператор определён")
                self.monitor_operator_status.setStyleSheet("color: green; font-weight: bold;")
            else:
                self.monitor_operator_status.setText("❌ Оператор не определён")
                self.monitor_operator_status.setStyleSheet("color: red; font-weight: bold;")
                
        except Exception as e:
            print(f"ОШИБКА обработки лица: {e}")
            
    def periodic_face_check(self):
        """Периодическая проверка лица"""
        try:
            # Дополнительные проверки каждые 5 секунд
            pass
        except Exception as e:
            print(f"ОШИБКА периодической проверки: {e}")
            
    def update_csv_with_drive_duration(self):
        """Обновление CSV с временем в дороге"""
        try:
            csv_file = Path("database") / "operators_db.csv"
            if not csv_file.exists():
                return
                
            rows = []
            with open(csv_file, "r", encoding="utf-8") as f:
                reader = csv.reader(f)
                rows = list(reader)
            
            for i, row in enumerate(rows):
                if len(row) > 0 and str(row[0]) == str(self.operator_id):
                    work_elapsed = datetime.now() - self.start_time
                    hours, remainder = divmod(work_elapsed.total_seconds(), 3600)
                    minutes, seconds = divmod(remainder, 60)
                    drive_duration = f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"
                    
                    if len(row) >= 9:
                        row[8] = drive_duration
                    else:
                        while len(row) < 9:
                            row.append("")
                        row[8] = drive_duration
                    break
            
            with open(csv_file, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerows(rows)
                
        except Exception as e:
            print(f"ОШИБКА обновления CSV: {e}")
        
    def closeEvent(self, event):
        """БЕЗОПАСНОЕ закрытие окна"""
        try:
            print("Закрытие окна мониторинга...")
            
            # Обновляем CSV перед закрытием
            self.update_csv_with_drive_duration()
            
            # Останавливаем камеру
            if self.camera_thread:
                self.camera_thread.stop_camera()
                
            # Останавливаем таймеры
            if hasattr(self, 'time_timer'):
                self.time_timer.stop()
            if hasattr(self, 'face_check_timer'):
                self.face_check_timer.stop()
                
            print("Окно мониторинга закрыто безопасно")
            event.accept()
            
        except Exception as e:
            print(f"ОШИБКА при закрытии: {e}")
            event.accept()  # Все равно закрываем