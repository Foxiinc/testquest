#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QFrame, QScrollArea
)
from PySide6.QtCore import Qt, QPoint
from PySide6.QtGui import QFont, QPixmap, QPainter, QPen, QBrush, QPolygon
from pathlib import Path


class GeometricIndicator(QLabel):
    """Виджет для отображения геометрических индикаторов"""
    
    def __init__(self, shape, color, size=40):
        super().__init__()
        self.shape = shape  # "circle", "triangle", "square"
        self.color = color
        self.size = size
        self.setFixedSize(size, size)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        pen = QPen(self.color, 2)
        brush = QBrush(self.color)
        painter.setPen(pen)
        painter.setBrush(brush)
        
        if self.shape == "circle":
            painter.drawEllipse(2, 2, self.size-4, self.size-4)
        elif self.shape == "triangle":
            points = [
                QPoint(self.size//2, 2),
                QPoint(2, self.size-2),
                QPoint(self.size-2, self.size-2)
            ]
            polygon = QPolygon(points)
            painter.drawPolygon(polygon)
        elif self.shape == "square":
            painter.drawRect(2, 2, self.size-4, self.size-4)


class InstructionWindow(QMainWindow):
    """Форма №3 - Инструкция"""
    
    def __init__(self, main_app, operator_data):
        super().__init__()
        self.main_app = main_app
        self.operator_data = operator_data
        self.init_ui()
        
    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("НейроБодр - Инструкция")
        self.setMinimumSize(1200, 700)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной GridLayout
        main_layout = QGridLayout(central_widget)
        main_layout.setSpacing(5)
        
        # Ряд 0: Кнопки меню (левый), Плашка НейроБодр (центр), Идентификация (правый)
        menu_widget = self.create_menu_widget()
        main_layout.addWidget(menu_widget, 0, 0, 1, 1)
        
        header_widget = self.create_header_widget()
        main_layout.addWidget(header_widget, 0, 1, 1, 1)
        
        id_widget = self.create_identification_widget()
        main_layout.addWidget(id_widget, 0, 2, 1, 1)
        
        # Ряд 1: Инструкция (левые 2 колонки) и Вид подключения (правая)
        instruction_widget = self.create_instruction_widget()
        main_layout.addWidget(instruction_widget, 1, 0, 1, 2)
        
        connection_widget = self.create_connection_widget()
        main_layout.addWidget(connection_widget, 1, 2, 1, 1)
        
        # Настройка пропорций
        main_layout.setRowStretch(0, 1)  # Верхняя строка
        main_layout.setRowStretch(1, 3)  # Нижняя строка больше
        main_layout.setColumnStretch(0, 1)
        main_layout.setColumnStretch(1, 2)
        main_layout.setColumnStretch(2, 1)
        
    def create_menu_widget(self):
        """Создание блока меню управления"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        # Заголовок
        title = QLabel("Меню управления")
        title.setFont(QFont("Arial", 12, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Кнопки горизонтально
        buttons_layout = QHBoxLayout()
        buttons_layout.setAlignment(Qt.AlignCenter)
        
        # Кнопка Инструкция (активная)
        instruction_btn = QPushButton("Инструкция")
        instruction_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
        """)
        
        # Кнопка Анализ
        analysis_btn = QPushButton("Анализ")
        analysis_btn.setStyleSheet("""
            QPushButton {
                background-color: #9C27B0;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #7B1FA2;
            }
        """)
        analysis_btn.clicked.connect(self.open_analysis)
        
        # Кнопка Управление
        control_btn = QPushButton("Управление")
        control_btn.setStyleSheet("""
            QPushButton {
                background-color: #9C27B0;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #7B1FA2;
            }
        """)
        control_btn.clicked.connect(self.open_control)
        
        buttons_layout.addWidget(instruction_btn)
        buttons_layout.addWidget(analysis_btn)
        buttons_layout.addWidget(control_btn)
        
        layout.addLayout(buttons_layout)
        layout.addStretch()
        
        return widget
        
    def create_header_widget(self):
        """Создание блока названия программы"""
        widget = QFrame()
        widget.setStyleSheet("background-color: #4CAF50; color: white;")
        
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(2)
        
        title = QLabel("НейроБодр")
        title.setFont(QFont("Arial", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("text-decoration: underline;")
        
        subtitle = QLabel("Программа для мониторинга состояния водителей")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setAlignment(Qt.AlignCenter)
        
        layout.addWidget(title)
        layout.addWidget(subtitle)
        return widget
        
    def create_identification_widget(self):
        """Создание блока идентификации"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Идентификация")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        status_label = QLabel("Оператор определён:")
        layout.addWidget(status_label)
        
        if self.operator_data:
            name_text = f"{self.operator_data.get('surname', '')} {self.operator_data.get('name', '')}"
            name_label = QLabel(name_text)
            name_label.setFont(QFont("Arial", 12, QFont.Bold))
            layout.addWidget(name_label)
        
        layout.addStretch()
        return widget
        
    def create_instruction_widget(self):
        """Создание блока инструкции"""
        widget = QFrame()
        widget.setStyleSheet("background-color: #f0f0f0;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Инструкция")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        layout.addWidget(title)
        
        # Зеленый круг - Норма
        green_layout = QHBoxLayout()
        green_indicator = GeometricIndicator("circle", Qt.green, 40)
        green_layout.addWidget(green_indicator)
        green_text = QLabel("Зеленый индикатор означает хорошее состояние оператора. Оператор бодрствует. ЧСС в пределах нормы. \"Норма\"")
        green_text.setWordWrap(True)
        green_text.setStyleSheet("color: green; font-weight: bold; font-size: 16px;")
        green_layout.addWidget(green_text)
        layout.addLayout(green_layout)
        
        # Желтый треугольник - Внимание
        yellow_layout = QHBoxLayout()
        yellow_indicator = GeometricIndicator("triangle", Qt.yellow, 40)
        yellow_layout.addWidget(yellow_indicator)
        yellow_text = QLabel("Желтый индикатор означает \"Внимание\". Состояние оператора выходит за пределы нормы: Падение ЧСС ниже 50 уд./мин или выше не более 90 уд./мин. Веки закрыты дольше 3 секунд (микросон). Наклон вперед/вбок (эффект \"кивающей головы\")")
        yellow_text.setWordWrap(True)
        yellow_text.setStyleSheet("color: orange; font-weight: bold; font-size: 16px;")
        yellow_layout.addWidget(yellow_text)
        layout.addLayout(yellow_layout)
        
        # Красный квадрат - Критическое
        red_layout = QHBoxLayout()
        red_indicator = GeometricIndicator("square", Qt.red, 40)
        red_layout.addWidget(red_indicator)
        red_text = QLabel("Красный индикатор означает \"Критическое\" состояние: ЧСС 38–42 уд./мин в минуту и ниже. ЧСС больше 100–130 ударов. Наклон головы вперед/вбок (дольше 4 секунд). Веки закрыты")
        red_text.setWordWrap(True)
        red_text.setStyleSheet("color: red; font-weight: bold; font-size: 16px;")
        red_layout.addWidget(red_text)
        layout.addLayout(red_layout)
        
        layout.addStretch()
        return widget
        
    def create_connection_widget(self):
        """Создание блока вид подключения"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Вид подключения")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        # Картинка 1
        img1_path = Path("assets") / "Hand_1.jpg"
        if img1_path.exists():
            img1_label = QLabel()
            pixmap1 = QPixmap(str(img1_path))
            scaled_pixmap1 = pixmap1.scaled(150, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            img1_label.setPixmap(scaled_pixmap1)
            img1_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(img1_label)
        
        # Картинка 2
        img2_path = Path("assets") / "Hand_2.jpg"
        if img2_path.exists():
            img2_label = QLabel()
            pixmap2 = QPixmap(str(img2_path))
            scaled_pixmap2 = pixmap2.scaled(150, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            img2_label.setPixmap(scaled_pixmap2)
            img2_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(img2_label)
        
        # Подпись
        instruction_text = QLabel("Наклеить электроды как показано на рисунке и подключить контакты")
        instruction_text.setWordWrap(True)
        instruction_text.setAlignment(Qt.AlignCenter)
        instruction_text.setStyleSheet("font-weight: bold; color: #333;")
        layout.addWidget(instruction_text)
        
        layout.addStretch()
        
        # Кнопка Далее
        next_btn = QPushButton("Далее")
        next_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                font-size: 14px;
                font-weight: bold;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
            }
            QPushButton:hover {
                background-color: #555555;
            }
        """)
        next_btn.clicked.connect(self.open_analysis)
        layout.addWidget(next_btn)
        
        return widget
        
    def open_analysis(self):
        """Открыть форму анализа"""
        self.main_app.show_analysis(self.operator_data)
        self.close()
        
    def open_control(self):
        """Открыть форму управления"""
        self.main_app.show_control(self.operator_data)
        self.close()