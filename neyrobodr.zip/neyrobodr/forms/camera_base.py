#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import cv2
import numpy as np
import face_recognition
from PySide6.QtCore import QThread, Signal


class CameraThread(QThread):
    """Поток для работы с камерой"""
    frame_ready = Signal(np.ndarray)
    face_detected = Signal(bool, np.ndarray)
    
    def __init__(self):
        super().__init__()
        self.cap = None
        self.running = False
        
    def start_camera(self):
        """Запуск камеры"""
        try:
            backends = [cv2.CAP_ANY, cv2.CAP_DSHOW, cv2.CAP_MSMF]
            
            for backend in backends:
                try:
                    self.cap = cv2.VideoCapture(0, backend)
                    if self.cap.isOpened():
                        ret, test_frame = self.cap.read()
                        if ret and test_frame is not None:
                            print(f"Камера запущена с backend: {backend}")
                            break
                        else:
                            self.cap.release()
                            self.cap = None
                    else:
                        self.cap = None
                except Exception as e:
                    print(f"Backend {backend} не работает: {e}")
                    continue
            
            if not self.cap or not self.cap.isOpened():
                return False
                
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
            
            self.running = True
            self.start()
            return True
        except Exception as e:
            print(f"Ошибка запуска камеры: {e}")
            return False
        
    def stop_camera(self):
        """Остановка камеры"""
        self.running = False
        if self.cap:
            self.cap.release()
        self.quit()
        self.wait()
        
    def run(self):
        """Основной цикл"""
        consecutive_fails = 0
        while self.running and self.cap and self.cap.isOpened():
            try:
                ret, frame = self.cap.read()
                if ret and frame is not None:
                    consecutive_fails = 0
                    self.frame_ready.emit(frame)
                    
                    if not hasattr(self, 'frame_count'):
                        self.frame_count = 0
                    self.frame_count += 1
                    
                    if self.frame_count % 15 == 0:
                        try:
                            small_frame = cv2.resize(frame, (0, 0), fx=1, fy=1)
                            rgb_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                            face_locations = face_recognition.face_locations(rgb_frame)
                            
                            if face_locations:
                                face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
                                if face_encodings:
                                    self.face_detected.emit(True, face_encodings[0])
                                else:
                                    self.face_detected.emit(False, np.array([]))
                            else:
                                self.face_detected.emit(False, np.array([]))
                        except:
                            self.face_detected.emit(False, np.array([]))
                else:
                    consecutive_fails += 1
                    if consecutive_fails > 20:
                        break
                        
            except Exception as e:
                consecutive_fails += 1
                if consecutive_fails > 20:
                    print(f"Критическая ошибка: {e}")
                    break
                
            self.msleep(66)