#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
import random
import numpy as np
from datetime import datetime
from pathlib import Path
import cv2
import face_recognition

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, 
    QPushButton, QLabel, QLineEdit, QSpinBox, QFrame, QMessageBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QPixmap, QImage

from .camera_base import CameraThread


class RegistrationWindow(QMainWindow):
    """Окно регистрации оператора"""
    
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.camera_thread = CameraThread()
        self.current_face_encoding = None
        self.face_encodings_buffer = []
        self.operator_id = None
        self.init_ui()
        self.setup_camera()
        
    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("НейроБодр")
        self.setMinimumSize(1200, 500)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(10)
        
        # Зеленая полоса сверху
        header = QFrame()
        header.setStyleSheet("background-color: #4CAF50; color: white; padding: 8px;")
        header.setFixedHeight(100)
        
        header_layout = QVBoxLayout(header)
        header_layout.setSpacing(2)
        header_layout.setAlignment(Qt.AlignCenter)
        
        title = QLabel("НейроБодр")
        title.setFont(QFont("Arial", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("text-decoration: underline;")
        
        subtitle = QLabel("Программа для мониторинга состояния водителей")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setAlignment(Qt.AlignCenter)
        
        header_layout.addWidget(title)
        header_layout.addWidget(subtitle)
        
        # Основной контент
        content_widget = QWidget()
        content_layout = QGridLayout(content_widget)
        content_layout.setSpacing(15)
        
        left_widget = self.create_registration_form()
        content_layout.addWidget(left_widget, 0, 0)
        
        center_widget = self.create_camera_widget()
        content_layout.addWidget(center_widget, 0, 1)
        
        right_widget = self.create_info_widget()
        content_layout.addWidget(right_widget, 0, 2)
        
        content_layout.setColumnStretch(0, 1)
        content_layout.setColumnStretch(1, 2)
        content_layout.setColumnStretch(2, 1)
        
        main_layout.addWidget(header)
        main_layout.addWidget(content_widget)
        
        # Кнопка "Далее"
        self.next_btn = QPushButton("Далее")
        self.next_btn.setEnabled(False)
        self.next_btn.setFixedSize(100, 35)
        self.next_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                font-size: 14px;
                padding: 8px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
            QPushButton:hover {
                background-color: #555555;
            }
        """)
        self.next_btn.clicked.connect(self.proceed_to_instruction)
        
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.next_btn)
        main_layout.addLayout(button_layout)
        
    def create_registration_form(self):
        """Создание формы регистрации"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        title = QLabel("Регистрация оператора")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        layout.addWidget(QLabel("Фамилия"))
        self.surname_edit = QLineEdit()
        layout.addWidget(self.surname_edit)
        
        layout.addWidget(QLabel("Имя"))
        self.name_edit = QLineEdit()
        layout.addWidget(self.name_edit)
        
        layout.addWidget(QLabel("Отчество"))
        self.patronymic_edit = QLineEdit()
        layout.addWidget(self.patronymic_edit)
        
        layout.addWidget(QLabel("Возраст"))
        self.age_spinbox = QSpinBox()
        self.age_spinbox.setRange(16, 100)
        self.age_spinbox.setValue(18)
        layout.addWidget(self.age_spinbox)
        
        record_btn = QPushButton("Записать")
        record_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                font-size: 12px;
                padding: 8px;
                border: none;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #555555;
            }
        """)
        record_btn.clicked.connect(self.record_operator)
        layout.addWidget(record_btn)
        
        layout.addStretch()
        return widget
        
    def create_camera_widget(self):
        """Создание виджета камеры"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignCenter)
        
        title = QLabel("Идентификация")
        title.setFont(QFont("Arial", 12, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        self.video_frame = QLabel()
        self.video_frame.setFixedSize(350, 250)
        self.video_frame.setStyleSheet("border: 2px solid #cccccc; background-color: #f0f0f0;")
        self.video_frame.setAlignment(Qt.AlignCenter)
        self.video_frame.setText("Инициализация камеры...")
        layout.addWidget(self.video_frame, 0, Qt.AlignCenter)
        
        self.camera_status = QLabel("❌ Оператор не определён")
        self.camera_status.setAlignment(Qt.AlignCenter)
        self.camera_status.setStyleSheet("color: red; font-weight: bold; font-size: 12px;")
        layout.addWidget(self.camera_status)
        
        return widget
        
    def create_info_widget(self):
        """Создание информационного блока"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        title = QLabel("Информационный блок")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        self.operator_status = QLabel("❌ Оператор не определён")
        self.operator_status.setStyleSheet("color: red; font-weight: bold;")
        layout.addWidget(self.operator_status)
        
        self.id_label = QLabel("ID не присвоен")
        self.id_label.setStyleSheet("""
            background-color: #F44336;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
        """)
        layout.addWidget(self.id_label)
        
        self.launch_status = QLabel("Запуск программы невозможен")
        self.launch_status.setStyleSheet("color: red; font-style: italic;")
        layout.addWidget(self.launch_status)
        
        layout.addStretch()
        return widget
        
    def setup_camera(self):
        """Настройка камеры"""
        self.camera_thread.frame_ready.connect(self.update_video_frame)
        self.camera_thread.face_detected.connect(self.on_face_detected)
        
        try:
            if self.camera_thread.start_camera():
                print("Камера запущена успешно")
            else:
                self.video_frame.setText("Камера недоступна\\n(можно продолжить без неё)")
        except Exception as e:
            self.video_frame.setText("Камера недоступна\\n(можно продолжить без неё)")
            print(f"Ошибка инициализации камеры: {e}")
            
    def update_video_frame(self, frame):
        """Обновление кадра видео"""
        try:
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            if hasattr(self, 'face_found') and self.face_found:
                small_frame = cv2.resize(rgb_frame, (0, 0), fx=0.25, fy=0.25)
                face_locations = face_recognition.face_locations(small_frame)
                
                if face_locations:
                    top, right, bottom, left = face_locations[0]
                    top *= 4
                    right *= 4
                    bottom *= 4
                    left *= 4
                    
                    cv2.rectangle(rgb_frame, (left, top), (right, bottom), (0, 255, 0), 3)
            
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w
            qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            
            pixmap = QPixmap.fromImage(qt_image)
            scaled_pixmap = pixmap.scaled(self.video_frame.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            
            self.video_frame.setPixmap(scaled_pixmap)
            
        except Exception as e:
            print(f"Ошибка обновления видео: {e}")
            
    def on_face_detected(self, found, encoding):
        """Обработка обнаружения лица"""
        self.face_found = found
        
        if found and len(encoding) > 0:
            self.camera_status.setText("✅ Оператор определён")
            self.camera_status.setStyleSheet("color: green; font-weight: bold; font-size: 14px;")
            
            self.face_encodings_buffer.append(encoding)
            if len(self.face_encodings_buffer) > 5:
                self.face_encodings_buffer.pop(0)
                
            if len(self.face_encodings_buffer) >= 3:
                self.current_face_encoding = np.mean(self.face_encodings_buffer, axis=0)
        else:
            self.camera_status.setText("❌ Оператор не определён")
            self.camera_status.setStyleSheet("color: red; font-weight: bold; font-size: 14px;")
            
    def record_operator(self):
        """Запись данных оператора"""
        if not all([self.surname_edit.text(), self.name_edit.text(), self.patronymic_edit.text()]):
            QMessageBox.warning(self, "Ошибка", "Заполните все поля!")
            return

        try:
            self.operator_id = self.generate_unique_id()
            current_time = datetime.now()

            self.save_to_csv(
                self.operator_id,
                self.surname_edit.text(),
                self.name_edit.text(),
                self.patronymic_edit.text(),
                self.age_spinbox.value(),
                current_time.date(),
                current_time.time(),
                current_time.time()
            )

            if hasattr(self, 'current_face_encoding') and self.current_face_encoding is not None:
                npy_path = Path("database") / f"{self.operator_id}.npy"
                np.save(npy_path, self.current_face_encoding)

            self.save_operator_photo()

            self.operator_status.setText("✅ Оператор зарегистрирован")
            self.operator_status.setStyleSheet("color: green; font-weight: bold;")

            self.id_label.setText(f"ID {self.operator_id}")
            self.id_label.setStyleSheet("""
                background-color: #4CAF50;
                color: white;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            """)

            self.launch_status.setText("Готов к запуску программы")
            self.launch_status.setStyleSheet("color: green; font-style: normal;")

            self.next_btn.setEnabled(True)

            QMessageBox.information(self, "Успех", f"Оператор зарегистрирован!\nID: {self.operator_id}")
            
            # Переходим к инструкции
            operator_data = {
                "id": self.operator_id,
                "surname": self.surname_edit.text(),
                "name": self.name_edit.text(),
                "patronymic": self.patronymic_edit.text(),
                "age": self.age_spinbox.value()
            }
            
            QTimer.singleShot(1000, lambda: self.main_app.show_registration_instruction(operator_data))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка сохранения: {e}")
            
    def save_to_csv(self, operator_id, last_name, first_name, middle_name, age, date, time, software_start_time=None, drive_duration=None):
        """Сохранение данных в CSV файл"""
        csv_file = Path("database") / "operators_db.csv"
        file_exists = csv_file.exists()
        
        with open(csv_file, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            
            if not file_exists:
                writer.writerow(["id", "last_name", "first_name", "middle_name", "age", "date", "time", "software_start_time", "drive_duration"])
            
            writer.writerow([
                operator_id,
                last_name,
                first_name, 
                middle_name,
                age,
                date.strftime("%Y-%m-%d") if hasattr(date, 'strftime') else str(date),
                time.strftime("%H:%M:%S") if hasattr(time, 'strftime') else str(time),
                software_start_time.strftime("%H:%M:%S") if software_start_time and hasattr(software_start_time, 'strftime') else software_start_time or "",
                drive_duration or ""
            ])
            
    def generate_unique_id(self):
        """Генерация уникального 6-значного ID"""
        csv_file = Path("database") / "operators_db.csv"
        existing_ids = set()
        
        if csv_file.exists():
            try:
                with open(csv_file, "r", encoding="utf-8") as f:
                    reader = csv.reader(f)
                    next(reader, None)
                    for row in reader:
                        if row and row[0].isdigit():
                            existing_ids.add(int(row[0]))
            except:
                pass
                    
        while True:
            new_id = random.randint(100000, 999999)
            if new_id not in existing_ids:
                return new_id
                
    def save_operator_photo(self):
        """Сохранение фото оператора"""
        try:
            if (hasattr(self.camera_thread, 'cap') and 
                self.camera_thread.cap and 
                self.camera_thread.cap.isOpened()):
                ret, frame = self.camera_thread.cap.read()
                if ret:
                    photo_path = Path("photos") / f"{self.operator_id}.jpg"
                    cv2.imwrite(str(photo_path), frame)
                    print(f"Фото сохранено: {photo_path}")
        except Exception as e:
            print(f"Ошибка сохранения фото: {e}")
            
    def proceed_to_instruction(self):
        """Переход к инструкции"""
        operator_data = {
            "id": self.operator_id,
            "surname": self.surname_edit.text(),
            "name": self.name_edit.text(),
            "patronymic": self.patronymic_edit.text(),
            "age": self.age_spinbox.value()
        }
        
        self.camera_thread.stop_camera()
        self.main_app.show_registration_instruction(operator_data)
        
    def closeEvent(self, event):
        """Обработка закрытия окна"""
        self.camera_thread.stop_camera()
        event.accept()