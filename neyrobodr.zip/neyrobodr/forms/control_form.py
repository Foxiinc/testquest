import sys
import csv
from datetime import datetime, timedelta
from pathlib import Path
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                            QLabel, QPushButton, QFrame, QTextEdit, QApplication, QStackedWidget, QGraphicsView, QGraphicsScene)
from PySide6.QtCore import Qt, QTimer, Signal, QUrl, QPoint
from PySide6.QtGui import QFont, QPixmap, QPainter, QColor, QPen, QBrush, QPolygon
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget, QGraphicsVideoItem
from arduino_pulse import ArduinoPulseReader, find_arduino_port
from enhanced_camera import CameraWidget
from services.state_client import RemoteState, push_state


class GeometricIndicator(QLabel):

    
    def __init__(self, shape, color, size=30):
        super().__init__()
        self.shape = shape  
        self.color = color
        self.size = size
        self.setFixedSize(size, size)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        pen = QPen(self.color, 2)
        brush = QBrush(self.color)
        painter.setPen(pen)
        painter.setBrush(brush)
        
        if self.shape == "circle":
            painter.drawEllipse(2, 2, self.size-4, self.size-4)
        elif self.shape == "triangle":
            points = [
                QPoint(self.size//2, 2),
                QPoint(2, self.size-2),
                QPoint(self.size-2, self.size-2)
            ]
            polygon = QPolygon(points)
            painter.drawPolygon(polygon)
        elif self.shape == "square":
            painter.drawRect(2, 2, self.size-4, self.size-4)


class ControlForm(QMainWindow):
    """Форма №5 - Управление"""
    
    def __init__(self, main_app, operator_data):
        super().__init__()
        self.main_app = main_app
        self.operator_data = operator_data
        self.start_time = datetime.now()
        self.current_pulse = 75
        self.operator_status = "NORMAL"
        self.last_alert_message = ""
        
        # Флаги состояний от камеры
        self.microsleep_active = False
        self.head_nod_active = False
        
        self.setup_ui()
        self.setup_timers()
        self.setup_video()
        self.setup_camera()
        
    def setup_ui(self):
        """Настройка интерфейса"""
        self.setWindowTitle("НейроБодр - Управление")
        self.setMinimumSize(1200, 700)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной GridLayout как в старых формах
        main_layout = QGridLayout(central_widget)
        main_layout.setSpacing(5)
        
        # Ряд 0: Кнопки меню (левый), Плашка НейроБодр (центр), Идентификация (правый)
        menu_widget = self.create_menu_widget()
        main_layout.addWidget(menu_widget, 0, 0, 1, 1)
        
        header_widget = self.create_header_widget()
        main_layout.addWidget(header_widget, 0, 1, 1, 1)
        
        id_widget = self.create_identification_widget()
        main_layout.addWidget(id_widget, 0, 2, 1, 1)
        
        # Ряд 1: Левая колонка (терминал + время) и Видео блок (правые 2 колонки)
        left_column = self.create_left_column()
        main_layout.addWidget(left_column, 1, 0, 1, 1)
        
        video_widget = self.create_video_widget()
        main_layout.addWidget(video_widget, 1, 1, 1, 2)
        
        # Настройка пропорций
        main_layout.setRowStretch(0, 1)  # Верхняя строка
        main_layout.setRowStretch(1, 4)  # Нижняя строка больше
        main_layout.setColumnStretch(0, 1)
        main_layout.setColumnStretch(1, 2)
        main_layout.setColumnStretch(2, 1)
        
    def create_menu_widget(self):
        """Создание блока меню управления"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        # Заголовок
        title = QLabel("Меню управления")
        title.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Кнопки горизонтально
        buttons_layout = QHBoxLayout()
        buttons_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Кнопка Инструкция
        instruction_btn = QPushButton("Инструкция")
        instruction_btn.setStyleSheet("""
            QPushButton {
                background-color: #9C27B0;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #7B1FA2;
            }
        """)
        instruction_btn.clicked.connect(self.open_instruction)
        
        # Кнопка Анализ
        analysis_btn = QPushButton("Анализ")
        analysis_btn.setStyleSheet("""
            QPushButton {
                background-color: #9C27B0;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #7B1FA2;
            }
        """)
        analysis_btn.clicked.connect(self.open_analysis)
        
        # Кнопка Управление (активная)
        control_btn = QPushButton("Управление")
        control_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
        """)
        
        buttons_layout.addWidget(instruction_btn)
        buttons_layout.addWidget(analysis_btn)
        buttons_layout.addWidget(control_btn)
        
        layout.addLayout(buttons_layout)
        layout.addStretch()
        
        return widget
        
    def create_header_widget(self):
        """Создание блока названия программы"""
        widget = QFrame()
        widget.setStyleSheet("background-color: #4CAF50; color: white;")
        
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(2)
        
        title = QLabel("НейроБод")
        title.setFont(QFont("Arial", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("text-decoration: underline;")
        
        subtitle = QLabel("Программа для мониторинга состояния водителей")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        layout.addWidget(title)
        layout.addWidget(subtitle)
        return widget
        
    def create_identification_widget(self):
        """Создание блока идентификации"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Идентификация")
        title.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        layout.addWidget(title)
        
        status_label = QLabel("Оператор определён:")
        layout.addWidget(status_label)
        
        if self.operator_data:
            name_text = f"{self.operator_data.get('last_name', '')} {self.operator_data.get('first_name', '')}"
            name_label = QLabel(name_text)
            name_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
            layout.addWidget(name_label)
        
        layout.addStretch()
        return widget
        
    def create_left_column(self):
        """Создание левой колонки с терминалом и временем"""
        widget = QFrame()
        widget.setStyleSheet("background-color: #f0f0f0;")
        
        layout = QVBoxLayout(widget)
        
        # Блок информации
        info_frame = QFrame()
        info_frame.setStyleSheet("background-color: white; border-radius: 5px; padding: 10px; margin: 5px;")
        info_layout = QVBoxLayout(info_frame)
        
        self.label_datetime = QLabel()
        self.label_start_time = QLabel()
        self.label_status = QLabel()
        
        info_layout.addWidget(self.label_datetime)
        info_layout.addWidget(self.label_start_time)
        info_layout.addWidget(self.label_status)
        
        layout.addWidget(info_frame)
        
        # Терминальный блок
        terminal_frame = QFrame()
        terminal_frame.setStyleSheet("background-color: #2E2E2E; border-radius: 5px; padding: 5px; margin: 5px;")
        terminal_layout = QVBoxLayout(terminal_frame)
        
        terminal_title = QLabel("Терминальный блок")
        terminal_title.setStyleSheet("color: white; font-weight: bold; font-size: 12px;")
        
        self.terminal_text = QLabel()
        self.terminal_text.setStyleSheet("""
            background-color: #1E1E1E;
            color: white;
            font-family: 'Arial';
            font-size: 14px;
            font-weight: bold;
            border: none;
            padding: 10px;
        """)
        self.terminal_text.setMinimumHeight(180)
        self.terminal_text.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.terminal_text.setWordWrap(True)
        self.terminal_text.setText("Состояние: НОРМА\nПульс: 75 уд/мин")
        
        terminal_layout.addWidget(terminal_title)
        terminal_layout.addWidget(self.terminal_text)
        
        layout.addWidget(terminal_frame)
        
        # Блок "Допустимое время"
        time_frame = QFrame()
        time_frame.setStyleSheet("background-color: white; border-radius: 5px; padding: 10px; margin: 5px;")
        time_layout = QVBoxLayout(time_frame)
        time_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        time_title = QLabel("Допустимое время")
        time_title.setStyleSheet("font-weight: bold; color: #333;")
        time_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.time_display = QLabel("09:00:00")
        self.time_display.setStyleSheet("font-size: 24px; font-weight: bold; color: #2196F3; font-family: 'Courier New';")
        self.time_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        time_layout.addWidget(time_title)
        time_layout.addWidget(self.time_display)
        
        layout.addWidget(time_frame)
        layout.addStretch()
        
        return widget
        
    def create_video_widget(self):
        """Создание видео блока с QGraphicsView"""
        # Главный контейнер
        main_container = QWidget()
        main_container.setStyleSheet("background-color: black;")
        
        # Layout для контейнера
        layout = QVBoxLayout(main_container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Создаем QGraphicsView для видео
        self.graphics_view = QGraphicsView()
        self.graphics_view.setStyleSheet("background-color: black; border: none;")
        self.graphics_scene = QGraphicsScene()
        self.graphics_view.setScene(self.graphics_scene)
        
        # Видео элемент
        self.video_item = QGraphicsVideoItem()
        self.graphics_scene.addItem(self.video_item)
        
        layout.addWidget(self.graphics_view)
        
        # OVERLAY ПАНЕЛЬ ПОВЕРХ ВИДЕО
        self.overlay_container = QFrame(main_container)
        self.overlay_container.setStyleSheet("""
            QFrame {
                background-color: rgba(0, 0, 0, 150);
                border-radius: 10px;
                border: 2px solid white;
            }
        """)
        self.overlay_container.setFixedSize(600, 100)
        self.overlay_container.move(30, 30)
        
        overlay_layout = QHBoxLayout(self.overlay_container)
        overlay_layout.setContentsMargins(20, 15, 20, 15)
        overlay_layout.setSpacing(15)
        
        # ИНДИКАТОРЫ
        self.circle_indicator = GeometricIndicator("circle", QColor(100, 100, 100, 100), 50)
        self.triangle_indicator = GeometricIndicator("triangle", QColor(100, 100, 100, 100), 50)
        self.square_indicator = GeometricIndicator("square", QColor(100, 100, 100, 100), 50)
        
        # ПУЛЬС
        self.pulse_label = QLabel("ПУЛЬС: 75")
        self.pulse_label.setFont(QFont("Arial", 28, QFont.Weight.Bold))
        self.pulse_label.setStyleSheet("color: #4CAF50; background: transparent;")
        
        overlay_layout.addWidget(self.circle_indicator)
        overlay_layout.addWidget(self.triangle_indicator)
        overlay_layout.addWidget(self.square_indicator)
        overlay_layout.addWidget(self.pulse_label)
        overlay_layout.addStretch()
        
        # КАМЕРА ОПЕРАТОРА
        self.camera_widget = CameraWidget(main_container)
        self.camera_widget.setFixedSize(200, 150)
        self.camera_widget.move(400, 30)
        
        # Подключаем сигналы камеры
        self.camera_widget.camera_thread.eyes_status.connect(self.on_eyes_status)
        self.camera_widget.camera_thread.head_tilt.connect(self.on_head_tilt)
        self.camera_widget.camera_thread.face_detected.connect(self.on_face_detected)
        self.camera_widget.camera_thread.microsleep_detected.connect(self.on_microsleep)
        self.camera_widget.camera_thread.head_nod_detected.connect(self.on_head_nod)
        
        return main_container
        

    def showEvent(self, event):
        """Позиционирование overlay элементов"""
        if hasattr(self, 'overlay_container'):
            self.overlay_container.raise_()
        if hasattr(self, 'operator_video'):
            # Позиционируем камеру справа
            container = self.operator_video.parent()
            if container:
                cam_x = container.width() - 230
                self.operator_video.move(cam_x, 30)
            self.operator_video.raise_()
        """Позиционирование overlay элементов при показе"""
        super().showEvent(event)
        # Задержка для показа overlay
        QTimer.singleShot(500, self.show_overlay_elements)
        
    def show_overlay_elements(self):
        """Показ overlay элементов"""
        if hasattr(self, 'overlay_container'):
            self.overlay_container.setVisible(True)
            self.overlay_container.raise_()
        if hasattr(self, 'operator_video'):
            self.operator_video.setVisible(True)
            self.operator_video.raise_()
            
    def resizeEvent(self, event):
        """Позиционирование виджетов при изменении размера"""
        super().resizeEvent(event)
        # Перемасштабируем видео
        if hasattr(self, 'video_item') and hasattr(self, 'graphics_view'):
            self.video_item.setSize(self.graphics_view.size())
            self.graphics_view.fitInView(self.video_item, Qt.AspectRatioMode.KeepAspectRatioByExpanding)
        
        # Позиционируем overlay
        if hasattr(self, 'camera_widget'):
            container = self.camera_widget.parent()
            if container:
                cam_x = max(30, container.width() - 230)
                self.camera_widget.move(cam_x, 30)
        
    def setup_video(self):
        """Настройка видео плеера"""
        self.media_player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.media_player.setAudioOutput(self.audio_output)
        self.media_player.setVideoOutput(self.video_item)
        
        # Растягиваем видео на весь размер view
        self.video_item.setSize(self.graphics_view.size())
        self.graphics_view.fitInView(self.video_item, Qt.AspectRatioMode.KeepAspectRatioByExpanding)
        
        # Загрузка видео
        video_path = Path("assets") / "Захватывающее вождение от первого лица..mp4"
        if video_path.exists():
            self.media_player.setSource(QUrl.fromLocalFile(str(video_path.absolute())))
            self.media_player.play()
            
            
        # Поднимаем overlay элементы
        QTimer.singleShot(100, self.raise_overlays)
        
    def raise_overlays(self):
        """Поднятие overlay элементов"""
        if hasattr(self, 'overlay_container'):
            self.overlay_container.raise_()
        if hasattr(self, 'camera_widget'):
            self.camera_widget.raise_()
        
    def setup_camera(self):
        """Настройка камеры"""
        if hasattr(self, 'camera_widget'):
            self.camera_widget.start_camera()
                
    def on_eyes_status(self, eyes_open):
        """Обработка статуса глаз"""
        pass  # Обрабатываем в on_microsleep
            
    def on_head_tilt(self, angle):
        """Обработка наклона головы"""
        pass  # Обрабатываем в on_head_nod
            
    def on_face_detected(self, detected, encoding):
        """Обработка обнаружения лица"""
        pass
            
    def on_microsleep(self, detected):
        """Обработка микросна (глаза закрыты >3 сек)"""
        self.microsleep_active = detected
        if detected:
            # Переводим в состояние WARNING
            if self.operator_status == "NORMAL":
                self.operator_status = "WARNING"
                self.update_pulse_display()
                self.play_warning_alert()

                
                
        else:
            # Пересчитываем статус
            self.recalculate_status()
                
    def on_head_nod(self, detected):
        """Обработка кивания головы (наклон >4 сек)"""
        self.head_nod_active = detected
        if detected:
            # Переводим в состояние CRITICAL
            self.operator_status = "CRITICAL"
            self.update_pulse_display()
            self.play_critical_alert()
        else:
            # Пересчитываем статус
            self.recalculate_status()
            
    def recalculate_status(self):
        """Пересчет статуса на основе всех параметров"""
        old_status = self.operator_status
        
        # Приоритет: кивание головы (КРИТИЧНО) > пульс > микросон (ВНИМАНИЕ)
        if self.head_nod_active:
            self.operator_status = "CRITICAL"
        elif self.current_pulse <= 42 or self.current_pulse >= 110:
            self.operator_status = "CRITICAL"
        elif self.microsleep_active or self.current_pulse < 50 or self.current_pulse > 90:
            self.operator_status = "WARNING"
        else:
            self.operator_status = "NORMAL"
            self.last_alert_message = ""  # Очищаем сообщение при норме
            
        # Обновляем индикаторы и оповещения
        self.update_pulse_display()
        
        if old_status != self.operator_status:
            if self.operator_status == "WARNING":
                self.play_warning_alert()
            elif self.operator_status == "CRITICAL":
                self.play_critical_alert()
            
    def play_warning_alert(self):
        """Звуковое оповещение для WARNING"""
        self.last_alert_message = "🔔 ЗВУКОВОЕ ОПОВЕЩЕНИЕ:\nВНИМАНИЕ, ОПЕРАТОР!\nОСТАНОВИТЕ ДВИЖЕНИЕ!"
        self.update_terminal_display()
        
    def play_critical_alert(self):
        """Звуковое оповещение для CRITICAL"""
        self.last_alert_message = "🚨 ЗВУКОВОЕ ОПОВЕЩЕНИЕ:\nВНИМАНИЕ, ОПЕРАТОР!\nВАШЕ СОСТОЯНИЕ КРИТИЧНО!!!\nНЕМЕДЛЕННО ОСТАНОВИТЕ ДВИЖЕНИЕ!"
        self.update_terminal_display()
        """Поднятие overlay элементов"""
        if hasattr(self, 'overlay_container'):
            self.overlay_container.raise_()
        if hasattr(self, 'operator_video'):
            self.operator_video.raise_()
            
    def setup_timers(self):
        """Настройка таймеров"""
        # Таймер для обновления времени и статуса
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_info)
        self.update_timer.start(1000)
        
        # Попытка подключения к Arduino
        self.setup_arduino()
        
        # Запускаем симуляцию по умолчанию (будет остановлена при подключении Arduino)
        self.pulse_timer = QTimer()
        self.pulse_timer.timeout.connect(self.simulate_pulse)
        self.pulse_timer.start(3000)
            
    def setup_arduino(self):
        """Настройка подключения к Arduino"""
        try:
            self.arduino_reader = ArduinoPulseReader()
            self.arduino_reader.pulse_received.connect(self.on_arduino_pulse)
            self.arduino_reader.connection_status.connect(self.on_arduino_connection)
            
            # Пытаемся подключиться
            if self.arduino_reader.start_reading():
                print("Arduino подключен")
            else:
                print("Arduino не найден, используем симуляцию")
                
        except Exception as e:
            print(f"Ошибка Arduino: {e}")
            
    def on_arduino_connection(self):
        """Обработка статуса подключения Arduino"""
        
        self.pulse_timer = QTimer()
        self.pulse_timer.timeout.connect(self.simulate_pulse)
        self.pulse_timer.start(3000)

            
    def on_arduino_pulse(self, pulse_value):
        """Обработка полученного с Arduino пульса"""
        self.current_pulse = pulse_value
        self.recalculate_status()
        self.save_operator_data()
        
    def update_info(self):
        """Обновление информации"""
        now = datetime.now()
        
        self.label_datetime.setText(f"Дата/время: {now.strftime('%d.%m.%Y %H:%M:%S')}")
        self.label_start_time.setText(f"Время запуска: {self.start_time.strftime('%H:%M:%S')}")
        
        self.update_status()
        
        # Обновление допустимого времени (обратный отсчет)
        elapsed = now - self.start_time
        remaining = timedelta(hours=9) - elapsed
        
        if remaining.total_seconds() > 0:
            hours = int(remaining.total_seconds() // 3600)
            minutes = int((remaining.total_seconds() % 3600) // 60)
            seconds = int(remaining.total_seconds() % 60)
            self.time_display.setText(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
        else:
            self.time_display.setText("00:00:00")
            
    def simulate_pulse(self):
        """Симуляция изменения пульса"""
        import random
        
        base_pulse = 90
        variation = random.randint(-20, 20)
        self.current_pulse = base_pulse + variation
        
        # Пересчитываем статус
        self.recalculate_status()
        
        # Сохранение данных
        self.save_operator_data()
        
    def update_status(self):
        """Обновление статуса оператора"""
        if self.operator_status == "NORMAL":
            self.label_status.setText("Состояние: НОРМА")
            self.label_status.setStyleSheet("color: #4CAF50; font-weight: bold; font-size: 14px;")
        elif self.operator_status == "WARNING":
            self.label_status.setText("Состояние: ВНИМАНИЕ")
            self.label_status.setStyleSheet("color: #FF9800; font-weight: bold; font-size: 14px;")
        else:
            self.label_status.setText("Состояние: КРИТИЧНО")
            self.label_status.setStyleSheet("color: #F44336; font-weight: bold; font-size: 14px;")
            
    def update_pulse_display(self):
        """Обновление отображения пульса и индикаторов"""
        self.pulse_label.setText(f"ПУЛЬС: {self.current_pulse}")
        
        # Обновляем терминальный блок
        self.update_terminal_display()
        
        # Сбрасываем все индикаторы в прозрачные
        self.circle_indicator.color = QColor(100, 100, 100, 100)
        self.triangle_indicator.color = QColor(100, 100, 100, 100)
        self.square_indicator.color = QColor(100, 100, 100, 100)
        
        # Зажигаем нужный индикатор и меняем цвет пульса
        if self.operator_status == "NORMAL":
            self.circle_indicator.color = QColor(0, 255, 0)  # Зеленый круг
            self.pulse_label.setStyleSheet("color: #4CAF50; background: transparent; font-weight: bold;")
            if hasattr(self, 'camera_widget'):
                self.camera_widget.setStyleSheet("""
                    QLabel {
                        border: 4px solid #4CAF50;
                        border-radius: 10px;
                        background-color: black;
                    }
                """)
        elif self.operator_status == "WARNING":
            self.triangle_indicator.color = QColor(255, 255, 0)  # Желтый треугольник
            self.pulse_label.setStyleSheet("color: #F4C542; background: transparent; font-weight: bold;")
            if hasattr(self, 'camera_widget'):
                self.camera_widget.setStyleSheet("""
                    QLabel {
                        border: 4px solid #F4C542;
                        border-radius: 10px;
                        background-color: black;
                    }
                """)
        else:  # CRITICAL
            self.square_indicator.color = QColor(255, 0, 0)  # Красный квадрат
            self.pulse_label.setStyleSheet("color: #E53935; background: transparent; font-weight: bold;")
            if hasattr(self, 'camera_widget'):
                self.camera_widget.setStyleSheet("""
                    QLabel {
                        border: 4px solid #E53935;
                        border-radius: 10px;
                        background-color: black;
                    }
                """)
            
        # Перерисовываем все индикаторы
        self.circle_indicator.update()
        self.triangle_indicator.update()
        self.square_indicator.update()
        
    def play_status_alert(self):
        """Воспроизведение звукового оповещения"""
        if self.operator_status == "WARNING":
            self.add_terminal_message("🔔 ВНИМАНИЕ! Запуск звукового оповещения")
        elif self.operator_status == "CRITICAL":
            self.add_terminal_message("🚨 КРИТИЧНО! Запуск звукового оповещения!")
            
    def update_terminal_display(self):
        """Обновление терминального блока"""
        status_text = "НОРМА"
        if self.operator_status == "WARNING":
            status_text = "ВНИМАНИЕ"
        elif self.operator_status == "CRITICAL":
            status_text = "КРИТИЧНО"
            
        terminal_content = f"Состояние: {status_text}\nПульс: {self.current_pulse} уд/мин"
        
        # Добавляем оповещение о звуковом сигнале ТОЛЬКО при WARNING или CRITICAL
        if (self.operator_status == "WARNING" or self.operator_status == "CRITICAL") and hasattr(self, 'last_alert_message') and self.last_alert_message:
            terminal_content += f"\n\n{self.last_alert_message}"
            
        self.terminal_text.setText(terminal_content)
            
    def save_operator_data(self):
        """Сохранение данных оператора в CSV и отправка на веб‑сервер"""
        try:
            csv_file = Path("database") / "operators_db.csv"
            
            now = datetime.now()
            drive_duration = now - self.start_time
            
            hours = int(drive_duration.total_seconds() // 3600)
            minutes = int((drive_duration.total_seconds() % 3600) // 60)
            seconds = int(drive_duration.total_seconds() % 60)
            drive_time_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
            
            rows = []
            if csv_file.exists():
                with open(csv_file, "r", encoding="utf-8") as f:
                    reader = csv.reader(f)
                    rows = list(reader)
            
            operator_id = self.operator_data.get('id')
            updated = False
            
            for i, row in enumerate(rows[1:], 1):
                if len(row) > 0 and str(row[0]) == str(operator_id):
                    if len(row) >= 13:
                        row[6] = now.strftime("%H:%M:%S")
                        row[8] = drive_time_str
                        row[11] = str(self.current_pulse)
                        row[12] = self.operator_status
                    updated = True
                    break
                    
            if not updated and len(rows) > 0:
                new_row = [
                    operator_id,
                    self.operator_data.get('last_name', ''),
                    self.operator_data.get('first_name', ''),
                    self.operator_data.get('middle_name', ''),
                    self.operator_data.get('age', ''),
                    now.strftime("%Y-%m-%d"),
                    now.strftime("%H:%M:%S"),
                    self.start_time.strftime("%H:%M:%S"),
                    drive_time_str,
                    "100",
                    "60-80",
                    str(self.current_pulse),
                    self.operator_status
                ]
                rows.append(new_row)
                
            with open(csv_file, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerows(rows)

            # Дополнительно отправляем актуальное состояние на FastAPI‑сервер
            try:
                state = RemoteState(
                    id=str(operator_id),
                    last_name=str(self.operator_data.get('last_name', '')),
                    first_name=str(self.operator_data.get('first_name', '')),
                    middle_name=str(self.operator_data.get('middle_name', '')),
                    age=str(self.operator_data.get('age', '')),
                    date=now.strftime("%Y-%m-%d"),
                    time=now.strftime("%H:%M:%S"),
                    software_start_time=self.start_time.strftime("%H:%M:%S"),
                    drive_duration=drive_time_str,
                    current_pulse=int(self.current_pulse),
                    operator_status=self.operator_status,
                )
                push_state(state)
            except Exception as send_err:
                # Для конкурса важнее не упасть — просто логируем в stdout
                print(f"Ошибка отправки состояния на сервер: {send_err}")
                
        except Exception as e:
            print(f"Ошибка сохранения данных: {e}")
            
    def open_instruction(self):
        """Открыть форму инструкции"""
        if self.main_app:
            self.main_app.show_instruction(self.operator_data)
            self.close()
        
    def open_analysis(self):
        """Открыть форму анализа"""
        if self.main_app:
            self.main_app.show_analysis(self.operator_data)
            self.close()
        
    def closeEvent(self, event):
        """Обработка закрытия окна"""
        # Остановка таймеров
        if hasattr(self, 'pulse_timer'):
            self.pulse_timer.stop()
        if hasattr(self, 'update_timer'):
            self.update_timer.stop()
            
        # Остановка Arduino
        if hasattr(self, 'arduino_reader'):
            self.arduino_reader.stop_reading()
            self.arduino_reader.disconnect()
            
        # Остановка камеры
        if hasattr(self, 'camera_widget'):
            self.camera_widget.stop_camera()
            
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    test_data = {
        'id': '123456',
        'last_name': 'Иванов',
        'first_name': 'Иван',
        'middle_name': 'Иванович',
        'age': 30
    }
    
    window = ControlForm(None, test_data)
    window.show()
    
    sys.exit(app.exec())