#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class StartWindow(QWidget):
    """Стартовое окно выбора действий"""
    
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.init_ui()
        
    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("Выберите необходимые действия")
        self.setMinimumSize(500, 400)
        
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(20)
        
        title = QLabel("Выберите необходимые действия")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        reg_btn = QPushButton("Регистрация")
        reg_btn.setMinimumSize(200, 60)
        reg_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                font-size: 16px;
                font-weight: bold;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #555555;
            }
        """)
        reg_btn.clicked.connect(self.open_registration)
        
        auth_btn = QPushButton("Авторизация")
        auth_btn.setMinimumSize(200, 60)
        auth_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                font-size: 16px;
                font-weight: bold;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #555555;
            }
        """)
        auth_btn.clicked.connect(self.open_authorization)
        
        buttons_layout = QHBoxLayout()
        buttons_layout.setAlignment(Qt.AlignCenter)
        buttons_layout.setSpacing(20)
        
        buttons_layout.addWidget(reg_btn)
        buttons_layout.addWidget(auth_btn)
        
        layout.addLayout(buttons_layout)
        self.setLayout(layout)
        
    def open_registration(self):
        """Открыть окно регистрации"""
        self.main_app.show_registration()
        
    def open_authorization(self):
        """Открыть окно авторизации"""
        self.main_app.show_authorization()