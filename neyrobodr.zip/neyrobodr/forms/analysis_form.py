#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
import random
from datetime import datetime
from pathlib import Path

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QFrame, QLineEdit, QSpinBox, QMessageBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QPixmap


class AnalysisWindow(QMainWindow):
    """Форма №4 - Анкета (Анализ оператора)"""
    
    def __init__(self, main_app, operator_data, mode="registration"):
        super().__init__()
        self.main_app = main_app
        self.operator_data = operator_data
        self.mode = mode  # "registration" или "authorization"
        self.current_pulse = 0
        self.pulse_timer = QTimer()
        self.init_ui()
        self.setup_pulse_simulation()
        
    def init_ui(self):
        """Инициализация интерфейса"""
        title = "НейроБодр - Анализ (Регистрация)" if self.mode == "registration" else "НейроБодр - Анализ (Авторизация)"
        self.setWindowTitle(title)
        self.setMinimumSize(1200, 700)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной GridLayout
        main_layout = QGridLayout(central_widget)
        main_layout.setSpacing(5)
        
        # Ряд 0: Кнопки меню (левый), Плашка НейроБодр (центр), Идентификация (правый)
        menu_widget = self.create_menu_widget()
        main_layout.addWidget(menu_widget, 0, 0, 1, 1)
        
        header_widget = self.create_header_widget()
        main_layout.addWidget(header_widget, 0, 1, 1, 1)
        
        id_widget = self.create_identification_widget()
        main_layout.addWidget(id_widget, 0, 2, 1, 1)
        
        # Ряд 1: Анализ оператора (левые 2 колонки) и Вид подключения (правая)
        analysis_widget = self.create_analysis_widget()
        main_layout.addWidget(analysis_widget, 1, 0, 1, 2)
        
        connection_widget = self.create_connection_widget()
        main_layout.addWidget(connection_widget, 1, 2, 2, 1)
        
        # Ряд 2: Терминальный блок (под анализом, левые 2 колонки)
        terminal_widget = self.create_terminal_widget()
        main_layout.addWidget(terminal_widget, 2, 0, 1, 2)
        
        # Настройка пропорций
        main_layout.setRowStretch(0, 1)  # Верхняя строка
        main_layout.setRowStretch(1, 2)  # Анализ
        main_layout.setRowStretch(2, 1)  # Терминал
        main_layout.setColumnStretch(0, 1)
        main_layout.setColumnStretch(1, 2)
        main_layout.setColumnStretch(2, 1)
        
    def create_menu_widget(self):
        """Создание блока меню управления"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        # Заголовок
        title = QLabel("Меню управления")
        title.setFont(QFont("Arial", 12, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Кнопки горизонтально
        buttons_layout = QHBoxLayout()
        buttons_layout.setAlignment(Qt.AlignCenter)
        
        # Кнопка Инструкция
        instruction_btn = QPushButton("Инструкция")
        instruction_btn.setStyleSheet("""
            QPushButton {
                background-color: #9C27B0;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #7B1FA2;
            }
        """)
        instruction_btn.clicked.connect(self.open_instruction)
        
        # Кнопка Анализ (активная)
        analysis_btn = QPushButton("Анализ")
        analysis_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
        """)
        
        # Кнопка Управление
        control_btn = QPushButton("Управление")
        control_btn.setStyleSheet("""
            QPushButton {
                background-color: #9C27B0;
                color: white;
                font-size: 10px;
                font-weight: bold;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #7B1FA2;
            }
        """)
        control_btn.clicked.connect(self.open_control)
        
        buttons_layout.addWidget(instruction_btn)
        buttons_layout.addWidget(analysis_btn)
        buttons_layout.addWidget(control_btn)
        
        layout.addLayout(buttons_layout)
        layout.addStretch()
        
        return widget
        
    def create_header_widget(self):
        """Создание блока названия программы"""
        widget = QFrame()
        widget.setStyleSheet("background-color: #4CAF50; color: white;")
        
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(2)
        
        title = QLabel("НейроБодр")
        title.setFont(QFont("Arial", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("text-decoration: underline; font-size: 24px; font-weight: bold;")
        
        subtitle = QLabel("Программа для мониторинга состояния водителей")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("font-size: 12px;")
        
        layout.addWidget(title)
        layout.addWidget(subtitle)
        return widget
        
    def create_identification_widget(self):
        """Создание блока идентификации"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Идентификация")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        status_label = QLabel("Оператор определён:")
        layout.addWidget(status_label)
        
        if self.operator_data:
            name_text = f"{self.operator_data.get('surname', '')} {self.operator_data.get('name', '')}"
            name_label = QLabel(name_text)
            name_label.setFont(QFont("Arial", 12, QFont.Bold))
            layout.addWidget(name_label)
        
        layout.addStretch()
        return widget
        
    def create_analysis_widget(self):
        """Создание блока анализа оператора"""
        widget = QFrame()
        widget.setStyleSheet("background-color: #f0f0f0;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Анализ оператора")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        if self.mode == "registration":
            # Поля для регистрации
            form_layout = QGridLayout()
            
            # Порог пульса
            form_layout.addWidget(QLabel("Порог пульса (критический):"), 0, 0)
            self.pulse_threshold_edit = QSpinBox()
            self.pulse_threshold_edit.setRange(30, 200)
            self.pulse_threshold_edit.setValue(100)
            self.pulse_threshold_edit.setStyleSheet("background-color: white; padding: 5px;")
            form_layout.addWidget(self.pulse_threshold_edit, 0, 1)
            
            # Норма пульса
            form_layout.addWidget(QLabel("Норма пульса:"), 1, 0)
            self.pulse_normal_edit = QLineEdit()
            self.pulse_normal_edit.setPlaceholderText("Например: 60")
            self.pulse_normal_edit.setText("60")
            self.pulse_normal_edit.setStyleSheet("background-color: white; padding: 5px;")
            form_layout.addWidget(self.pulse_normal_edit, 1, 1)
            
            # Кнопка записать справа от вводов
            record_btn = QPushButton("Записать")
            record_btn.setStyleSheet("""
                QPushButton {
                    background-color: #333333;
                    color: white;
                    font-size: 12px;
                    font-weight: bold;
                    border: none;
                    border-radius: 5px;
                    padding: 8px 15px;
                }
                QPushButton:hover {
                    background-color: #555555;
                }
            """)
            record_btn.clicked.connect(self.save_pulse_data)
            form_layout.addWidget(record_btn, 0, 2, 2, 1)
            
            layout.addLayout(form_layout)
            
        else:
            # Режим авторизации - показываем сохраненные данные
            self.load_and_display_pulse_data(layout)
            
        layout.addStretch()
        return widget
        
    def create_terminal_widget(self):
        """Создание терминального блока информации"""
        widget = QFrame()
        widget.setStyleSheet("background-color: black; color: white;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Терминальный блок информации")
        title.setFont(QFont("Courier", 12, QFont.Bold))
        title.setStyleSheet("color: white;")
        layout.addWidget(title)
        
        # Статусы проверок
        self.signal_status = QLabel("Проверка сигнала: ОК")
        self.signal_status.setFont(QFont("Courier", 10))
        self.signal_status.setStyleSheet("color: white;")
        layout.addWidget(self.signal_status)
        
        self.pulse_check_status = QLabel("Проверка пульса: ОК")
        self.pulse_check_status.setFont(QFont("Courier", 10))
        self.pulse_check_status.setStyleSheet("color: white;")
        layout.addWidget(self.pulse_check_status)
        
        self.current_pulse_label = QLabel("Пульс: 0 уд/мин")
        self.current_pulse_label.setFont(QFont("Courier", 12, QFont.Bold))
        self.current_pulse_label.setStyleSheet("color: white;")
        layout.addWidget(self.current_pulse_label)
        
        # Сообщение о готовности
        self.ready_message = QLabel("")
        self.ready_message.setFont(QFont("Courier", 10))
        self.ready_message.setStyleSheet("color: white;")
        self.ready_message.setWordWrap(True)
        layout.addWidget(self.ready_message)
        
        layout.addStretch()
        
        return widget
        
    def create_connection_widget(self):
        """Создание блока вид подключения"""
        widget = QFrame()
        widget.setStyleSheet("background-color: white;")
        
        layout = QVBoxLayout(widget)
        
        title = QLabel("Вид подключения")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(title)
        
        # Картинка 1
        img1_path = Path("assets") / "Hand_1.jpg"
        if img1_path.exists():
            img1_label = QLabel()
            pixmap1 = QPixmap(str(img1_path))
            scaled_pixmap1 = pixmap1.scaled(150, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            img1_label.setPixmap(scaled_pixmap1)
            img1_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(img1_label)
        
        # Картинка 2
        img2_path = Path("assets") / "Hand_2.jpg"
        if img2_path.exists():
            img2_label = QLabel()
            pixmap2 = QPixmap(str(img2_path))
            scaled_pixmap2 = pixmap2.scaled(150, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            img2_label.setPixmap(scaled_pixmap2)
            img2_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(img2_label)
        
        # Подпись
        instruction_text = QLabel("Наклеить электроды как показано на рисунке и подключить контакты")
        instruction_text.setWordWrap(True)
        instruction_text.setAlignment(Qt.AlignCenter)
        instruction_text.setStyleSheet("font-weight: bold; color: #333;")
        layout.addWidget(instruction_text)
        
        layout.addStretch()
        
        # Кнопка Далее в правом нижнем углу
        self.next_btn = QPushButton("Далее")
        self.next_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                font-size: 14px;
                font-weight: bold;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
            }
            QPushButton:hover {
                background-color: #555555;
            }
        """)
        self.next_btn.clicked.connect(self.open_control)
        self.next_btn.setEnabled(False)
        layout.addWidget(self.next_btn)
        
        return widget
        
    def setup_pulse_simulation(self):
        """Настройка симуляции пульса"""
        self.pulse_timer.timeout.connect(self.update_pulse)
        self.pulse_timer.start(1000)  # Обновление каждую секунду
        
        # Симуляция проверок
        QTimer.singleShot(2000, self.complete_checks)
        
    def update_pulse(self):
        """Обновление показаний пульса"""
        # Симуляция реального пульса (60-80 с небольшими колебаниями)
        base_pulse = 70
        variation = random.randint(-10, 10)
        self.current_pulse = base_pulse + variation
        
        self.current_pulse_label.setText(f"Пульс: {self.current_pulse} уд/мин")
        
    def complete_checks(self):
        """Завершение проверок"""
        self.ready_message.setText("Для перехода в режим управление нажмите далее")
        self.next_btn.setEnabled(True)
        
    def save_pulse_data(self):
        """Сохранение данных о пульсе"""
        try:
            pulse_threshold = self.pulse_threshold_edit.value()
            pulse_normal = self.pulse_normal_edit.text().strip()
            
            if not pulse_normal:
                QMessageBox.warning(self, "Ошибка", "Заполните поле нормы пульса!")
                return
                
            # Обновляем CSV файл
            self.update_csv_with_pulse_data(pulse_threshold, pulse_normal)
            
            QMessageBox.information(self, "Успех", "Данные о пульсе сохранены!")
            
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка сохранения: {e}")
            
    def update_csv_with_pulse_data(self, pulse_threshold, pulse_normal):
        """Обновление CSV с данными о пульсе"""
        csv_file = Path("database") / "operators_db.csv"
        
        if not csv_file.exists():
            return
            
        # Читаем все строки
        rows = []
        with open(csv_file, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            rows = list(reader)
        
        # Обновляем заголовок если нужно
        if len(rows) > 0:
            header = rows[0]
            # Проверяем и добавляем новые поля
            new_fields = ["pulse_threshold_critical", "pulse_normal", "current_pulse"]
            for field in new_fields:
                if field not in header:
                    header.append(field)
        
        # Обновляем строку с нашим оператором
        operator_id = self.operator_data.get('id')
        for i, row in enumerate(rows[1:], 1):  # Пропускаем заголовок
            if len(row) > 0 and str(row[0]) == str(operator_id):
                # Дополняем строку до нужной длины
                while len(row) < len(header):
                    row.append("")
                
                # Обновляем поля пульса
                if "pulse_threshold_critical" in header:
                    row[header.index("pulse_threshold_critical")] = str(pulse_threshold)
                if "pulse_normal" in header:
                    row[header.index("pulse_normal")] = pulse_normal
                if "current_pulse" in header:
                    row[header.index("current_pulse")] = str(self.current_pulse)
                break
        
        # Записываем обратно
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerows(rows)
            
    def load_and_display_pulse_data(self, layout):
        """Загрузка и отображение данных о пульсе для режима авторизации"""
        try:
            csv_file = Path("database") / "operators_db.csv"
            if not csv_file.exists():
                layout.addWidget(QLabel("Данные о пульсе не найдены"))
                return
                
            operator_id = self.operator_data.get('id')
            
            with open(csv_file, "r", encoding="utf-8") as f:
                reader = csv.reader(f)
                header = next(reader, [])
                
                for row in reader:
                    if len(row) > 0 and str(row[0]) == str(operator_id):
                        # Показываем сохраненные данные
                        if "pulse_threshold_critical" in header and "pulse_normal" in header:
                            threshold_idx = header.index("pulse_threshold_critical")
                            normal_idx = header.index("pulse_normal")
                            
                            if len(row) > threshold_idx and row[threshold_idx]:
                                threshold_label = QLabel(f"Порог пульса (критический): {row[threshold_idx]}")
                                threshold_label.setFont(QFont("Arial", 12))
                                threshold_label.setStyleSheet("color: #333; padding: 5px; background-color: white;")
                                layout.addWidget(threshold_label)
                                
                            if len(row) > normal_idx and row[normal_idx]:
                                normal_label = QLabel(f"Норма пульса: {row[normal_idx]}")
                                normal_label.setFont(QFont("Arial", 12))
                                normal_label.setStyleSheet("color: #333; padding: 5px; background-color: white;")
                                layout.addWidget(normal_label)
                        else:
                            no_data_label = QLabel("Данные о пульсе не настроены")
                            no_data_label.setStyleSheet("color: orange; font-style: italic;")
                            layout.addWidget(no_data_label)
                        break
                        
        except Exception as e:
            print(f"Ошибка загрузки данных пульса: {e}")
            error_label = QLabel("Ошибка загрузки данных")
            error_label.setStyleSheet("color: red;")
            layout.addWidget(error_label)
            
    def open_instruction(self):
        """Открыть форму инструкции"""
        self.pulse_timer.stop()
        self.main_app.show_instruction(self.operator_data)
        self.close()
        
    def open_control(self):
        """Открыть форму управления (мониторинг)"""
        self.pulse_timer.stop()
        self.main_app.show_control(self.operator_data)
        self.close()
        
    def closeEvent(self, event):
        """Обработка закрытия окна"""
        self.pulse_timer.stop()
        event.accept()