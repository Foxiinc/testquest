#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Простой веб‑сервер для удалённого мониторинга (FastAPI).

Запуск:
    uvicorn api_server:app --reload
или:
    python api_server.py

ControlForm (Форма №5) шлёт сюда обновления состояния водителя,
а remote_monitor.py (Форма №6) опрашивает API и показывает в реальном времени.
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel


class OperatorState(BaseModel):
    id: str
    last_name: str
    first_name: str
    middle_name: str
    age: str
    date: str
    time: str
    software_start_time: str
    drive_duration: str
    current_pulse: int
    operator_status: str


app = FastAPI(title="Neurobodr Remote Monitor API")

_STATE: Dict[str, OperatorState] = {}


@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.now().isoformat(timespec="seconds")}


@app.post("/state", response_model=OperatorState)
def update_state(state: OperatorState):
    """Обновление/создание состояния оператора."""
    _STATE[state.id] = state
    return state


@app.get("/state/{operator_id}", response_model=OperatorState)
def get_state(operator_id: str):
    """Получить текущее состояние оператора."""
    state = _STATE.get(operator_id)
    if not state:
        raise HTTPException(status_code=404, detail="Operator not found")
    return state


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("api_server:app", host="127.0.0.1", port=8000, reload=False)

